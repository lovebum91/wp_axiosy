<?php
/**
 * Uninstall LbumManager
 *
 * @package LbumManager
 * @author lbum
 */

/* Make sure we're actually uninstalling the plugin. */
if ( !defined( 'WP_UNINSTALL_PLUGIN' ) )
	wp_die( sprintf( esc_html__( '%s should only be called when uninstalling the plugin.', 'axiosy' ), '<code>' . __FILE__ . '</code>' ) );


// Delete Plugin Options
delete_option( 'lbummanager_options' );