<?php
/**
 * Plugin Name: Lbum Manager
 * Plugin URI: https://wordpress.org/plugins/lbum-manager/
 * Description: A suite of custom post types, shortcode for Love Bum themes.
 * Version: 1.0.1
 * Author: LoveBum
 * Text Domain: lovebum
 * Domain Path: /languages/
 */
if ( !defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly

if ( !class_exists( 'LbumManager' ) ) {
    /**
     * Setup sortable gallery custom CMB field type.
     * Credits to mustardBees for most of this https://github.com/mustardBees/cmb-field-gallery
     *
     * @return void
     */
    define( 'LBUM_GALLERY_URL', plugin_dir_url( __FILE__ ) );
    define( 'LBUM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

    /**
     * Render field
     */
    function lbum_gallery_field( $field, $meta ) {
        wp_enqueue_script( 'lbum_gallery_init', LBUM_GALLERY_URL . 'js/script.js', array( 'jquery' ), null );

        if ( !empty( $meta ) ) {
            $meta = implode( ',', $meta );
        }
        echo '<div class="lbum-gallery">';
        echo '	<input type="hidden" id="' . $field['id'] . '" name="' . $field['id'] . '" value="' . $meta . '" />';
        echo '	<input type="button" class="button" value="' . (!empty( $field['button'] ) ? $field['button'] : 'Manage gallery' ) . '" />';
        echo '</div>';

        if ( !empty( $field['desc'] ) ) {
            echo '<p class="cmb_metabox_description">' . $field['desc'] . '</p>';
        }
    }

    add_filter( 'cmb_render_lbum_gallery', 'lbum_gallery_field', 10, 2 );

    /**
     * Split CSV string into an array of values
     */
    function lbum_gallery_field_sanitise( $meta_value, $field ) {
        if ( empty( $meta_value ) ) {
            $meta_value = '';
        } else {
            $meta_value = explode( ',', $meta_value );
        }

        return $meta_value;
    }

    function lbum_portfolio_recentthumb( $postid, $related = FALSE ) {
        $thumb = get_the_post_thumbnail( $postid, 'lbum-portfolio-4col', array( 'class' => 'lbum-thumbnail' ) );

        if ( $thumb == '' ) {
            $thumb = '<img src="' . esc_url($thumb) . '" alt="' . get_the_title() . '" class="lbum-thumbnail" />';
        }

        $output = '<span class="lbum-folio-img"><a title="' . get_the_title( $postid ) . '" href="' . esc_url(get_permalink( $postid )) . '">' . $thumb . '</a></span>';

        echo $output;
    }

    function lbum_portfoliothumbnail( $postid, $related = FALSE ) {
        if ( (is_page_template( 'template-portfolio-4col.php' )) || (is_page_template( 'single-tf_portfolio.php' )) ) {
            $thumb = get_the_post_thumbnail( $postid, 'lbum-portfolio-4col', array( 'class' => 'lbum-thumbnail' ) );

            if ( $thumb == '' ) {
                $thumb = '<img src="' . esc_url($thumb) . '" alt="' . get_the_title() . '" class="lbum-thumbnail" />';
            }

            $output = '<span class="lbum-folio-img"><a title="' . get_the_title( $postid ) . '" href="' . esc_url(get_permalink( $postid )) . '">' . $thumb . '</a></span>';

            echo $output;
        } elseif ( is_page_template( 'template-portfolio-3col.php' ) ) {
            $thumb = get_the_post_thumbnail( $postid, 'lbum-portfolio-3col', array( 'class' => 'lbum-thumbnail' ) );
            if ( $thumb == '' ) {
                $thumb = '<img src="' . esc_url($thumb) . '" alt="' . get_the_title() . '" class="lbum-thumbnail" />';
            }

            $output = '<span class="lbum-folio-img"><a title="' . get_the_title( $postid ) . '" href="' . esc_url(get_permalink( $postid )) . '">' . $thumb . '</a></span>';

            echo $output;
        } elseif ( is_page_template( 'template-portfolio-2col.php' ) ) {
            $thumb = get_the_post_thumbnail( $postid, 'lbum-portfolio-2col', array( 'class' => 'lbum-thumbnail' ) );
            if ( $thumb == '' ) {
                $thumb = '<img src="' . esc_url($thumb) . '" alt="' . get_the_title() . '" class="lbum-thumbnail" />';
            }

            $output = '<span class="lbum-folio-img"><a title="' . get_the_title( $postid ) . '" href="' . esc_url(get_permalink( $postid )) . '">' . $thumb . '</a></span>';

            echo $output;
        }
    }

    /**
     * Main LbumManager Class
     *
     * @package LbumManager
     * @version 1.0
     * @author LoveBum
     */
    class LbumManager {

        /**
         * @var string
         */
        public $version = '1.0.1';

        /**
         * @var string
         */
        public $plugin_url;

        /**
         * @var string
         */
        public $plugin_path;

        /**
         * @var string
         */
        public $template_url;

        /**
         * LbumManager Constructor.
         *
         * @access public
         * @return void
         */
        public function __construct() {
            // Define version constant
            define( 'LBUMMANAGER_VERSION', $this->version );
            // Hooks
            //add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'action_links' ) );
            add_action( 'init', array( &$this, 'init' ) );
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
        }

        public function enqueue_styles() {
            wp_enqueue_style( 'lbum_mger_styles', LBUM_PLUGIN_URL . 'css/lbum_mger.css' );
        }

        /**
         * Add custom links on plugins page.
         *
         * @access public
         * @param mixed $links
         * @return void
         */
        public function action_links( $links ) {
            $plugin_links = array(
                '<a href="' . admin_url( 'options-general.php?page=lbummanager' ) . '">' . esc_html__( 'Settings', 'axiosy' ) . '</a>'
            );

            return array_merge( $plugin_links, $links );
        }

        /**
         * Initialise LbumManager .
         *
         * @return void
         */
        function init() {
            $this->lbum_load_textdomain();

            add_filter( 'body_class', array( &$this, 'body_class' ) );

            /**
             * Include the Custom Post Types, Taxonomies, Custom fields and Shortcodes
             */
            // Post Types
            include_once( 'includes/post-types/brands.php');
            include_once( 'includes/post-types/recommend.php');
            include_once( 'includes/post-types/portfolio.php');
            include_once( 'includes/post-types/cookieannouncements.php');
            include_once( 'includes/post-types/testimonials.php');

            // Taxonomies
            include_once( 'includes/taxonomies/brandcategory.php');
            include_once( 'includes/taxonomies/recommendcategory.php');
            include_once( 'includes/taxonomies/portfoliocategory.php');

            // Custom fields
            include_once( 'includes/metaboxes/brands.php');
            include_once( 'includes/metaboxes/recommend.php');
            include_once( 'includes/metaboxes/portfolio.php');
            include_once( 'includes/metaboxes/cookieannouncements.php');
            include_once( 'includes/metaboxes/testimonials.php');
            

            // Shortcodes
            include_once( 'includes/shortcodes/blank_spacer.php');
            include_once( 'includes/shortcodes/heading_text.php');
            include_once( 'includes/shortcodes/lbum_buttons.php');
            include_once( 'includes/shortcodes/icon_box.php');
            include_once( 'includes/shortcodes/icon_list.php');
            include_once( 'includes/shortcodes/lbum_image.php');
            include_once( 'includes/shortcodes/lbum_tabs.php');
            include_once( 'includes/shortcodes/blockquote.php');
            include_once( 'includes/shortcodes/social_follow.php');
            include_once( 'includes/shortcodes/list_categories.php');
			include_once( 'includes/shortcodes/lbum_list_menu.php');
            include_once( 'includes/shortcodes/woocommerce_product_sliders.php');
            include_once( 'includes/shortcodes/latest_posts.php');
            include_once( 'includes/shortcodes/promo_message_box.php');
            include_once( 'includes/shortcodes/video_banner.php');
            include_once( 'includes/shortcodes/general-markup.php');
            include_once( 'includes/shortcodes/testimonials.php');
            include_once( 'includes/shortcodes/brands.php');
            include_once( 'includes/shortcodes/portfolio_slider.php');
            include_once( 'includes/shortcodes/content_strips.php');
            include_once( 'includes/shortcodes/lbum_countdown.php');
            include_once( 'includes/shortcodes/recommend.php');

            // Initialising Shortcodes
            if ( class_exists( 'WPBakeryVisualComposerAbstract' ) ) {
                //Shortcode
                add_shortcode( 'bartag', 'bartag_func' );

                function bartag_func( $atts, $content = null ) {
                    extract( shortcode_atts( array(
                        'foo' => 'something',
                        'color' => '#FFF'
                                    ), $atts ) );

                    $content = wpb_js_remove_wpautop( $content ); // fix unclosed/unwanted paragraph tags in $content
                    return "<div style='color:{$color};' data-foo='${foo}'>{$content}</div>";
                }

                //Lbum customize get Icon Icon Box, Icon List
                function lbum_icon_settings_field($settings, $value)
                {
                    $dependency = vc_generate_dependencies_attributes($settings);
                    $param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
                    $type = isset($settings['type']) ? $settings['type'] : '';
                    $class = isset($settings['class']) ? $settings['class'] : '';
                    $icons = array('ambulance','car','h-square','hospital-o','medkit','plus-square','stethoscope','user-md','wheelchair','adn','android','apple','bitbucket','bitbucket-square','bitcoin','btc','css3','dribbble','dropbox','facebook','facebook-square','flickr','foursquare','github','github-alt','github-square','gittip','google-plus','google-plus-square','html5','instagram','linkedin','linkedin-square','linux','maxcdn','pagelines','pinterest','pinterest-square','renren','skype','stack-exchange','stack-overflow','trello','tumblr','tumblr-square','twitter','twitter-square','vimeo-square','vk','weibo','windows','xing','xing-square','youtube','youtube-play','youtube-square','arrows-alt','backward','compress','eject','expand','fast-backward','fast-forward','forward','pause','play','play-circle','play-circle-o','step-backward','step-forward','stop','youtube-play','rub','ruble','rouble','pagelines','stack-exchange','arrow-circle-o-right','arrow-circle-o-left','caret-square-o-left','toggle-left','dot-circle-o','wheelchair','vimeo-square','try','turkish-lira','plus-square-o','adjust','anchor','archive','arrows','arrows-h','arrows-v','asterisk','ban','bar-chart-o','barcode','bars','beer','bell','bell-o','bolt','book','bookmark','bookmark-o','briefcase','bug','building-o','bullhorn','bullseye','calendar','calendar-o','camera','camera-retro','caret-square-o-down','caret-square-o-left','caret-square-o-right','caret-square-o-up','certificate','check','check-circle','check-circle-o','check-square','check-square-o','circle','circle-o','clock-o','cloud','cloud-download','cloud-upload','code','code-fork','coffee','cog','cogs','comment','comment-o','comments','comments-o','compass','credit-card','crop','crosshairs','cutlery','dashboard','desktop','dot-circle-o','download','edit','ellipsis-h','ellipsis-v','envelope','envelope-o','eraser','exchange','exclamation','exclamation-circle','exclamation-triangle','external-link','external-link-square','eye','eye-slash','female','fighter-jet','film','filter','fire','fire-extinguisher','flag','flag-checkered','flag-o','flash','flask','folder','folder-o','folder-open','folder-open-o','frown-o','gamepad','gavel','gear','gears','gift','glass','globe','group','hdd-o','headphones','heart','heart-o','home','inbox','info','info-circle','key','keyboard-o','laptop','leaf','legal','lemon-o','level-down','level-up','lightbulb-o','location-arrow','lock','magic','magnet','mail-forward','mail-reply','mail-reply-all','male','map-marker','meh-o','microphone','microphone-slash','minus','minus-circle','minus-square','minus-square-o','mobile','mobile-phone','money','moon-o','music','pencil','pencil-square','pencil-square-o','phone','phone-square','picture-o','plane','plus','plus-circle','plus-square','plus-square-o','power-off','print','puzzle-piece','qrcode','question','question-circle','quote-left','quote-right','random','refresh','reply','reply-all','retweet','road','rocket','rss','rss-square','search','search-minus','search-plus','share','share-square','share-square-o','shield','shopping-cart','sign-in','sign-out','signal','sitemap','smile-o','sort','sort-alpha-asc','sort-alpha-desc','sort-amount-asc','sort-amount-desc','sort-asc','sort-desc','sort-down','sort-numeric-asc','sort-numeric-desc','sort-up','spinner','square','square-o','star','star-half','star-half-empty','star-half-full','star-half-o','star-o','subscript','suitcase','sun-o','superscript','tablet','tachometer','tag','tags','tasks','terminal','thumb-tack','thumbs-down','thumbs-o-down','thumbs-o-up','thumbs-up','ticket','times','times-circle','times-circle-o','tint','toggle-down','toggle-left','toggle-right','toggle-up','trash-o','trophy','truck','umbrella','unlock','unlock-alt','unsorted','upload','user','users','video-camera','volume-down','volume-off','volume-up','warning','wheelchair','wrench','check-square','check-square-o','circle','circle-o','dot-circle-o','minus-square','minus-square-o','plus-square','plus-square-o','square','square-o','bitcoin','btc','cny','dollar','eur','euro','gbp','inr','jpy','krw','money','rmb','rouble','rub','ruble','rupee','try','turkish-lira','usd','won','align-center','align-justify','align-left','align-right','bold','chain','chain-broken','clipboard','columns','copy','cut','dedent','eraser','file','file-o','file-text','file-text-o','files-o','floppy-o','font','indent','italic','link','list','list-alt','list-ol','list-ul','outdent','paperclip','paste','repeat','rotate-left','rotate-right','save','scissors','strikethrough','table','text-height','text-width','th','th-large','th-list','underline','undo','unlink','angle-double-down','angle-double-left','angle-double-right','angle-double-up','angle-down','angle-left','angle-right','angle-up','arrow-circle-down','arrow-circle-left','arrow-circle-o-down','arrow-circle-o-left','arrow-circle-o-right','arrow-circle-o-up','arrow-circle-right','arrow-circle-up','arrow-down','arrow-left','arrow-right','arrow-up','arrows','arrows-alt','arrows-h','arrows-v','caret-down','caret-left','caret-right','caret-square-o-down','caret-square-o-left','caret-square-o-right','caret-square-o-up','caret-up','chevron-circle-down','chevron-circle-left','chevron-circle-right','chevron-circle-up','chevron-down','chevron-left','chevron-right','chevron-up','hand-o-down','hand-o-left','hand-o-right','hand-o-up','long-arrow-down','long-arrow-left','long-arrow-right','long-arrow-up','toggle-down','toggle-left','toggle-right','toggle-up',);

                    $output = '<input type="hidden" name="'.$param_name.'" class="wpb_vc_param_value '.$param_name.' '.$type.' '.$class.'" value="'.$value.'" id="trace"/>
                            <div class="icon-preview"><i class=" fa fa-'.$value.'"></i></div>';
                    $output .='<input class="search" type="text" placeholder="Search" />';
                    $output .='<div id="icon-dropdown" >';
                    $output .= '<ul class="icon-list">';
                    $n = 1;
                    foreach($icons as $icon)
                    {
                        $selected = ($icon == $value) ? 'class="selected"' : '';
                        $id = 'icon-'.$n;
                        $output .= '<li '.$selected.' data-icon="'.$icon.'"><i class="icon fa fa-'.$icon.'"></i><label class="icon">'.$icon.'</label></li>';
                        $n++;
                    }
                    $output .='</ul>';
                    $output .='</div>';
                    $output .= '<script type="text/javascript">
                            jQuery(document).ready(function(){
                                jQuery(".search").keyup(function(){
                             
                                    // Retrieve the input field text and reset the count to zero
                                    var filter = jQuery(this).val(), count = 0;
                             
                                    // Loop through the icon list
                                    jQuery(".icon-list li").each(function(){
                             
                                        // If the list item does not contain the text phrase fade it out
                                        if (jQuery(this).text().search(new RegExp(filter, "i")) < 0) {
                                            jQuery(this).fadeOut();
                                        } else {
                                            jQuery(this).show();
                                            count++;
                                        }
                                    });
                                });
                            });

                            jQuery("#icon-dropdown li").click(function() {
                                jQuery(this).attr("class","selected").siblings().removeAttr("class");
                                var icon = jQuery(this).attr("data-icon");
                                jQuery("#trace").val(icon);
                                jQuery(".icon-preview").html("<i class=\'icon fa fa-"+icon+"\'></i>");
                            });
                    </script>';
                    return $output;
                }
                if (function_exists('vc_add_shortcode_param')) {
                    vc_add_shortcode_param('icon' , 'lbum_icon_settings_field');
                }
            }

            // Initialize the metabox class
            add_action( 'init', 'lbum_initialize_cmb_meta_boxes', 9999 );

            function lbum_initialize_cmb_meta_boxes() {
                if ( !class_exists( 'cmb_Meta_Box' ) ) {
                    require_once( 'includes/metaboxes/cmb/init.php' );
                }
            }
        }

        /**
         * Setup localisation.
         *
         * @return void
         */
        function lbum_load_textdomain() {
            // Set filter for plugin's languages directory
            $lbummger = '';
            $lbummger_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
            $lbummger_lang_dir = apply_filters( 'lbummger_languages_directory', $lbummger_lang_dir );

            // Traditional WordPress plugin locale filter
            $locale = apply_filters( 'plugin_locale', get_locale(), 'axiosy' );
            $mofile = sprintf( '%1$s-%2$s.mo', 'axiosy', $locale );

            // Setup paths to current locale file
            $mofile_local = $lbummger_lang_dir . $mofile;
            $mofile_global = WP_LANG_DIR . '/lbum-manager/' . $mofile;

            if ( file_exists( $mofile_global ) ) {
                load_textdomain( 'axiosy', $mofile_global );
            } elseif ( file_exists( $mofile_local ) ) {
                load_textdomain( 'axiosy', $mofile_local );
            } else {
                // Load the default language files
                load_plugin_textdomain( 'axiosy', false, $lbummger_lang_dir );
            }
        }

        /**
         * Plugin path.
         *
         * @return string Plugin path
         */
        public function plugin_path() {
            if ( $this->plugin_path ) {
                return $this->plugin_path;
            }

            return $this->plugin_path = untrailingslashit( plugin_dir_path( __FILE__ ) );
        }

        /**
         * Plugin url.
         *
         * @return string Plugin url
         */
        public function plugin_url() {
            if ( $this->plugin_url ) {
                return $this->plugin_url;
            }

            return $this->plugin_url = untrailingslashit( plugins_url( '/', __FILE__ ) );
        }

        /**
         * Add lbummger to body class for use on frontend.
         *
         * @since 1.0.0
         * @return array $classes List of classes
         */
        public function body_class( $classes ) {
            $classes[] = 'lbummger';
            return $classes;
        }

    }

    $GLOBALS['lbummger'] = new LbumManager();
}

/**
 * Flush the rewrite rules on activation
 */
function lbummger_activation() {
    flush_rewrite_rules();
}

register_activation_hook( __FILE__, 'lbummger_activation' );

/**
 * Also flush the rewrite rules on deactivation
 */
function lbummger_deactivation() {
    flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, 'lbummger_activation' );