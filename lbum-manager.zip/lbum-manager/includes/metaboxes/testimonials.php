<?php

function lbum_testimonial_metaboxes( $meta_boxes ) {
    $prefix = '_lbum_'; // Prefix for all fields
    $meta_boxes['testimonial'] = array(
        'id' => 'testimonial_metabox',
        'title' => esc_html__( 'Testimonial Details', 'axiosy' ),
        'pages' => array( 'testimonials' ), // post type
        'context' => 'normal',
        'priority' => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                'name' => esc_html__( 'Name of person providing the testimonial', 'axiosy' ),
                'desc' => esc_html__( 'This can also be anonymous', 'axiosy' ),
                'id' => $prefix . 'testimonial_name',
                'type' => 'text'
            ),
            array(
                'name' => esc_html__( 'Organization name', 'axiosy' ),
                'desc' => esc_html__( 'Enter the organization your clients works for.', 'axiosy' ),
                'id' => $prefix . 'testimonial_org_name',
                'type' => 'text'
            ),
            array(
                'name' => esc_html__( 'Testimonial Face Profile Image', 'axiosy' ),
                'desc' => esc_html__( 'Upload an image or enter a URL.', 'axiosy' ),
                'id' => $prefix . 'testimonial_image',
                'type' => 'file',
            ),
        ),
    );

    return $meta_boxes;
}

add_filter( 'cmb_meta_boxes', 'lbum_testimonial_metaboxes' );
