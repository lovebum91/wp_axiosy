<?php

function lbum_portfolio_metaboxes( $meta_boxes ) {
    $prefix = '_lbum_'; // Prefix for all fields
    $meta_boxes['portfolio'] = array(
        'id' => 'portfolio_metabox',
        'title' => esc_html__( 'Portfolio Details', 'axiosy' ),
        'pages' => array( 'portfolios' ), // post type
        'context' => 'normal',
        'priority' => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                'name' => esc_html__( 'Portfolio url/link', 'axiosy' ),
                'desc' => esc_html__( 'Where the portfolio should link to. Please do not forget to include the http://', 'axiosy' ),
                'id' => $prefix . 'portfolio_url',
                'type' => 'text'
            ),
            array(
                'name' => esc_html__( 'Portfolio url/link description', 'axiosy' ),
                'desc' => esc_html__( 'This is the text description displayed when clicking on the portfolio url/link.', 'axiosy' ),
                'id' => $prefix . 'portfolio_url_desc',
                'type' => 'text'
            ),
            array(
                'name' => esc_html__( 'Portfolio image gallery', 'axiosy' ),
                'desc' => esc_html__( 'Upload images and they will be shown in a slideshow..', 'axiosy' ),
                'id' => $prefix . 'portfolio_gallery',
                'type' => 'cg_gallery',
                'sanitization_cb' => 'lbum_gallery_field_sanitise',
            ),
            array(
                'name' => esc_html__( 'Portfolio Video Source', 'axiosy' ),
                'desc' => esc_html__( 'As an alternative to a Portfolio image gallery, you can embed a portfolio video.', 'axiosy' ),
                'id' => $prefix . 'portfolio_video_source',
                'type' => 'select',
                'options' => array(
                    'youtube' => esc_html__( 'Youtube', 'axiosy' ),
                    'vimeo' => esc_html__( 'Vimeo', 'axiosy' ),
                ),
            ),
            array(
                'name' => esc_html__( 'Portfolio Video ID', 'axiosy' ),
                'desc' => esc_html__( 'Copy the ID of the video (E.g. http://www.youtube.com/watch?v=<strong>iiscGR8EuZM</strong>) you want to show..', 'axiosy' ),
                'id' => $prefix . 'portfolio_video_embed',
                'type' => 'textarea'
            ),
        ),
    );

    return $meta_boxes;
}

add_filter( 'cmb_meta_boxes', 'lbum_portfolio_metaboxes' );
