<?php

function lbum_shopannouncements_metaboxes( $meta_boxes ) {
    $prefix = '_lbum_'; // Prefix for all fields
    $meta_boxes['cookieannouncements'] = array(
        'id' => 'cookieannouncements_metabox',
        'title' => esc_html__( 'Cookie announcement title', 'axiosy' ),
        'pages' => array( 'cookieannouncements' ), // post type
        'context' => 'normal',
        'priority' => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                'name' => esc_html__( 'Announcement background color', 'axiosy' ),
                'desc' => esc_html__( 'The announcement has a solid background color', 'axiosy' ),
                'id' => $prefix . 'cookieannouncement_bgcolor',
                'type' => 'colorpicker',
                'default' => '#82b965'
            ),
            array(
                'name' => esc_html__( 'Announcement text color', 'axiosy' ),
                'desc' => esc_html__( 'The text color for the announcement', 'axiosy' ),
                'id' => $prefix . 'cookieannouncement_txtcolor',
                'type' => 'colorpicker',
                'default' => '#fff'
            ),
        ),
    );

    return $meta_boxes;
}

//add_filter( 'cmb_meta_boxes', 'lbum_shopannouncements_metaboxes' );
