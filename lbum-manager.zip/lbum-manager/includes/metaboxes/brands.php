<?php

function lbum_brands_metaboxes( $meta_boxes ) {
    $prefix = '_lbum_'; // Prefix for all fields
    $meta_boxes['logo'] = array(
        'id' => 'logo_metabox',
        'title' => esc_html__( 'Brands Details', 'axiosy' ),
        'pages' => array( 'brands' ), // post type
        'context' => 'normal',
        'priority' => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                'name' => esc_html__( 'Logo link destination', 'axiosy' ),
                'desc' => esc_html__( 'Where the logo should link to. Please do not forget to include the http://', 'axiosy' ),
                'id' => $prefix . 'logo_url',
                'type' => 'text'
            ),
            array(
                'name' => esc_html__( 'Logo image', 'axiosy' ),
                'desc' => esc_html__( 'Upload an image or enter a URL.', 'axiosy' ),
                'id' => $prefix . 'logo_image',
                'type' => 'file',
            ),
        ),
    );

    return $meta_boxes;
}

add_filter( 'cmb_meta_boxes', 'lbum_brands_metaboxes' );
