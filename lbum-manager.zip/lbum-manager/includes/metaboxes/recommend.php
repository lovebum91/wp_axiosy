<?php

function lbum_recommends_metaboxes( $meta_boxes ) {
    $prefix = '_lbum_'; // Prefix for all fields
    $meta_boxes['recommend'] = array(
        'id' => 'recommend_metabox',
        'title' => esc_html__( 'Recommends Details', 'axiosy' ),
        'pages' => array( 'recommends' ), // post type
        'context' => 'normal',
        'priority' => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                'name' => esc_html__( 'Title', 'axiosy' ),
                'desc' => esc_html__( 'The title show on image', 'axiosy' ),
                'id' => $prefix . 'title',
                'type' => 'text'
            ),
            array(
                'name' => esc_html__( 'Sub title', 'axiosy' ),
                'desc' => esc_html__( 'The sub title show on image', 'axiosy' ),
                'id' => $prefix . 'sub_title',
                'type' => 'text'
            ),
            array(
                'name' => esc_html__( 'Image link destination', 'axiosy' ),
                'desc' => esc_html__( 'Where the logo should link to. Please do not forget to include the http://', 'axiosy' ),
                'id' => $prefix . 'logo_url',
                'type' => 'text'
            ),
            array(
                'name' => esc_html__( 'Image', 'axiosy' ),
                'desc' => esc_html__( 'Upload an image or enter a URL.', 'axiosy' ),
                'id' => $prefix . 'logo_image',
                'type' => 'file',
            ),
        ),
    );

    return $meta_boxes;
}

add_filter( 'cmb_meta_boxes', 'lbum_recommends_metaboxes' );
