<?php

    $labels = array(
        'name' => _x('Recommends Categories', 'taxonomy general name', 'axiosy'),
        'singular_name' => _x('Recommends Category', 'taxonomy singular name', 'axiosy'),
        'search_items' => esc_html__('Search Recommends Categories', 'axiosy'),
        'popular_items' => esc_html__('Popular Recommends Categories', 'axiosy'),
        'all_items' => esc_html__('All Recommends Categories', 'axiosy'),
        'parent_item' => null,
        'parent_item_colon' => null,
        'edit_item' => esc_html__('Edit Recommends Category', 'axiosy'),
        'update_item' => esc_html__('Update Recommends Category', 'axiosy'),
        'add_new_item' => esc_html__('Add New Recommends Category', 'axiosy'),
        'new_item_name' => esc_html__('New Recommends Category Name', 'axiosy'),
        'separate_items_with_commas' => esc_html__('Separate recommends categories with commas', 'axiosy'),
        'add_or_remove_items' => esc_html__('Add or remove recommends categories', 'axiosy'),
        'choose_from_most_used' => esc_html__('Choose from the most used recommends categories', 'axiosy'),
    );

    register_taxonomy('lbum_recommendcategory', 'recommends', array(
        'label' => esc_html__('Recommends Category', 'axiosy'),
        'labels' => $labels,
        'hierarchical' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'recommend-category'),
    ));

?>