<?php

    $labels = array(
        'name' => _x('Portfolio Categories', 'taxonomy general name', 'axiosy'),
        'singular_name' => _x('Portfolio Category', 'taxonomy singular name', 'axiosy'),
        'search_items' => esc_html__('Search Portfolio Categories', 'axiosy'),
        'popular_items' => esc_html__('Popular Portfolio Categories', 'axiosy'),
        'all_items' => esc_html__('All Portfolio Categories', 'axiosy'),
        'parent_item' => null,
        'parent_item_colon' => null,
        'edit_item' => esc_html__('Edit Portfolio Category', 'axiosy'),
        'update_item' => esc_html__('Update Portfolio Category', 'axiosy'),
        'add_new_item' => esc_html__('Add New Portfolio Category', 'axiosy'),
        'new_item_name' => esc_html__('New Portfolio Category Name', 'axiosy'),
        'separate_items_with_commas' => esc_html__('Separate portfolio categories with commas', 'axiosy'),
        'add_or_remove_items' => esc_html__('Add or remove portfolio categories', 'axiosy'),
        'choose_from_most_used' => esc_html__('Choose from the most used portfolio categories', 'axiosy'),
    );

    register_taxonomy('lbum_portfoliocategory', 'portfolios', array(
        'label' => esc_html__('Portfolio Category', 'axiosy'),
        'labels' => $labels,
        'hierarchical' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'portfolio-category'),
    ));

?>