<?php

function lbum_owlslider_js_brands($owlsliderjsid){
	?>
	<script type="text/javascript">

	jQuery(document).ready(function($) {

		$("#owlslider_<?php echo $owlsliderjsid ?>").owlCarousel({
			autoPlay: 4000, 
			items : 5,
			pagination : false,
			stopOnHover : true,
			itemsDesktop : [1199,4],
			itemsDesktopSmall : [979,3]
		}); 
	});

	</script>

<?php }

// Brands 

function lbum_brands($atts, $content = null) {
	global $woocommerce;
	$owlid = rand();
	extract(shortcode_atts(array(
		"introtext" => 'Our Brands',
		"posts" => '10',
		"columns" => '4',
		"category" => '',
		"animation" => "none",
		'animation_delay' => '',
	), $atts));
	
	//Animation
	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = '';

	ob_start();
	?>
        
<?php lbum_owlslider_js_brands($owlid)?>

<?php if(!empty($animation) && $animation !="none"){?>
	<div class="lbum_brands <?php echo esc_attr($animation_style); ?>"  <?php echo $data_animation_style; echo $animation_delay; ?>>
<?php }else { ?>
	<div class="lbum_brands">
<?php }?>

	<div class="row">
		<div class="col-lg-12">
			<?php if(!empty($introtext)) : ?>
			<div class="titlewrap">
				<h2><?php echo $introtext; ?></h2>
			</div>
			<?php endif ?>
		</div>

		<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
			<?php
				$args = array(
								'post_type' 			=> 'brands',
								'post_status' 			=> 'publish',
								'ignore_sticky_posts'   => 1,
								'posts_per_page' 		=> $posts,
								'tax_query' 			=> array(
									array(
										'taxonomy' 		=> 'lbum_brandcategory',
										'terms' 		=> array(esc_attr($category)),
										'field' 		=> 'slug',
										'operator' 		=> 'IN'
									)
								),	
				);

				$brands = new WP_Query( $args );

				if ( $brands->have_posts() ) : ?>
				<?php while ( $brands->have_posts() ) : $brands->the_post(); ?>

				<?php 
				global $post;
				$logo_url 		= get_post_meta( $post->ID, '_lbum_logo_url', true ); 
				$logo_img 	= get_post_meta( $post->ID, '_lbum_logo_image', true ); 
				?>

				<div class="item">
					<a href="<?php echo esc_url($logo_url); ?>">
						<img alt="logo" src="<?php echo esc_url($logo_img); ?>">
					</a>
				</div>

			<?php endwhile; // end of the loop. ?>
			
			<?php
			endif; 
			wp_reset_postdata();
			?>

		</div>
	</div>
</div>

<?php 

	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

add_shortcode("lbum_brands", "lbum_brands");


