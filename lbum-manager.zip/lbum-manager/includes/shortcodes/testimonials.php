<?php
function lbum_owlslider_js_testimonials($owlsliderjsid, $count_items){
	?>
	<script type="text/javascript">

	jQuery(document).ready(function($) {

		$("#owlslider_<?php echo $owlsliderjsid ?>").owlCarousel({
			items : <?php echo $count_items; ?>,
			itemsDesktop : [1000,1], //5 items between 1000px and 901pxs
          	itemsDesktopSmall : [950,1], // 2 items betweem 900px and 601px
          	itemsTablet: [670,1], //2 items between 600 and 0;
          	itemsMobile : [450,1],
			lazyLoad : true,
			navigation : false,
			pagination: true,
		}); 
	});

	</script>

<?php }

// Latest Testimonials. 

function lbum_testimonials($atts, $content = null) {
	global $woocommerce;
	$owlid = rand();
	extract(shortcode_atts(array(
		"introtext" => '',
		'styles' => 'testimo01',
		"posts" => '8',
		'display_items' => '1',
		"category" => '',
		'bg_color' => '',
		'position_color' => '',
		'name_color' => '',
		'description_color' => '',
		"animation" => "none",
		'animation_delay' => '',
	), $atts));


	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = 'data-delay="'.$animation_delay.'"';

	ob_start();
	?>
        
<?php if($styles == 'testimo01'): ?> 
<?php lbum_owlslider_js_testimonials($owlid, $display_items)?>
<div <?php echo $data_animation_style; echo $animation_delay; ?> class="testimonials-wrap testimo01 <?php echo esc_attr($animation_style) ?>">
	<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
		<?php
			$args = array(
				'post_type' 			=> 'testimonials',
				'post_status' 			=> 'publish',
				'ignore_sticky_posts'   => 1,
				'posts_per_page' 		=> $posts
			);

			$testimonials = new WP_Query( $args );

			if ( $testimonials->have_posts() ) : ?>
			<?php while ( $testimonials->have_posts() ) : $testimonials->the_post(); ?>

			<?php 
			global $post;
			$testimonial_image 		= get_post_meta( $post->ID, '_lbum_testimonial_image', true );
			$testimonial_name 		= get_post_meta( $post->ID, '_lbum_testimonial_name', true ); 
			$testimonial_org_name 	= get_post_meta( $post->ID, '_lbum_testimonial_org_name', true ); 
			?>

			<div class="item">
				<div class="images">
					<img alt="<?php echo esc_attr($testimonial_name); ?>" src="<?php echo esc_url($testimonial_image); ?>" />
				</div>
				<div class="content-text">
				<p style="color:<?php echo esc_attr($description_color); ?>"><?php echo get_the_content(); ?></p>
				<span class="name" style="color:<?php echo esc_attr($name_color); ?>"><?php echo $testimonial_name; ?></span>
				<?php if ( !empty( $testimonial_org_name ) ){ ?> 
					<span class="position" style="color:<?php echo esc_attr($position_color); ?>"><?php echo ", ".$testimonial_org_name; ?></span>
				<?php } ?>
				</div>
			</div>

		<?php endwhile; // end of the loop. ?>
		
		<?php
		endif; 
		wp_reset_postdata();
		?>
	</div>
</div>

<?php elseif ($styles == 'testimo02'): ?>
<?php lbum_owlslider_js_testimonials($owlid, $display_items)?>
<div <?php echo $data_animation_style; echo $animation_delay; ?> class="testimonials-wrap testimo02 <?php echo $animation_style ?>">
	<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
		<?php
			$args = array(
				'post_type' 			=> 'testimonials',
				'post_status' 			=> 'publish',
				'ignore_sticky_posts'   => 1,
				'posts_per_page' 		=> $posts
			);

			$testimonials = new WP_Query( $args );

			if ( $testimonials->have_posts() ) : ?>
			<?php while ( $testimonials->have_posts() ) : $testimonials->the_post(); ?>

			<?php 
			global $post;
			$testimonial_image 		= get_post_meta( $post->ID, '_lbum_testimonial_image', true );
			$testimonial_name 		= get_post_meta( $post->ID, '_lbum_testimonial_name', true ); 
			$testimonial_org_name 	= get_post_meta( $post->ID, '_lbum_testimonial_org_name', true ); 
			?>

			<div class="item" style="background:<?php echo esc_attr($bg_color); ?>">
				<div class="images">
					<img style="border-color:<?php echo esc_attr($bg_color); ?>" alt="<?php echo esc_attr($testimonial_name); ?>" src="<?php echo esc_url($testimonial_image); ?>" />
				</div>
				<div class="content-text">
				<p style="color:<?php echo esc_attr($description_color); ?>"><?php echo get_the_content(); ?></p>
				<span class="name" style="color:<?php echo esc_attr($name_color); ?>"><?php echo $testimonial_name; ?></span>
				<?php if ( !empty( $testimonial_org_name ) ){ ?> 
					<span class="position" style="color:<?php echo esc_attr($position_color); ?>"><?php echo ", ".$testimonial_org_name; ?></span>
				<?php } ?>
				</div>
			</div>

		<?php endwhile; // end of the loop. ?>
		
		<?php
		endif; 
		wp_reset_postdata();
		?>
	</div>
</div>

<?php elseif ($styles == 'testimo03'): ?>
<?php lbum_owlslider_js_testimonials($owlid, $display_items)?>
<div <?php echo $data_animation_style; echo $animation_delay; ?> class="testimonials-wrap testimo03 <?php echo $animation_style ?>">
	<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
		<?php
			$args = array(
				'post_type' 			=> 'testimonials',
				'post_status' 			=> 'publish',
				'ignore_sticky_posts'   => 1,
				'posts_per_page' 		=> $posts
			);

			$testimonials = new WP_Query( $args );

			if ( $testimonials->have_posts() ) : ?>
			<?php while ( $testimonials->have_posts() ) : $testimonials->the_post(); ?>

			<?php 
			global $post;
			$testimonial_image 		= get_post_meta( $post->ID, '_lbum_testimonial_image', true );
			$testimonial_name 		= get_post_meta( $post->ID, '_lbum_testimonial_name', true ); 
			$testimonial_org_name 	= get_post_meta( $post->ID, '_lbum_testimonial_org_name', true ); 
			?>

			<div class="item">
				<div class="images">
					<img alt="<?php echo esc_attr($testimonial_name); ?>" src="<?php echo esc_url($testimonial_image); ?>" />
				</div>
				<div class="content-text">
				<p style="color:<?php echo esc_attr($description_color); ?>"><?php echo get_the_content(); ?></p>
				<span class="name" style="color:<?php echo esc_attr($name_color); ?>"><?php echo $testimonial_name; ?></span>
				<?php if ( !empty( $testimonial_org_name ) ){ ?> 
					<span class="position" style="color:<?php echo esc_attr($position_color); ?>"><?php echo ", ".$testimonial_org_name; ?></span>
				<?php } ?>
				</div>
			</div>

		<?php endwhile; // end of the loop. ?>
		
		<?php
		endif; 
		wp_reset_postdata();
		?>
	</div>
</div>

<?php else: ?>
<?php lbum_owlslider_js_testimonials($owlid, $display_items)?>
<div <?php echo $data_animation_style; echo $animation_delay; ?> class="testimonials-wrap testimo04 <?php echo $animation_style ?>">
	<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
		<?php
			$args = array(
				'post_type' 			=> 'testimonials',
				'post_status' 			=> 'publish',
				'ignore_sticky_posts'   => 1,
				'posts_per_page' 		=> $posts
			);

			$testimonials = new WP_Query( $args );

			if ( $testimonials->have_posts() ) : ?>
			<?php while ( $testimonials->have_posts() ) : $testimonials->the_post(); ?>

			<?php 
			global $post;
			$testimonial_image 		= get_post_meta( $post->ID, '_lbum_testimonial_image', true );
			$testimonial_name 		= get_post_meta( $post->ID, '_lbum_testimonial_name', true ); 
			$testimonial_org_name 	= get_post_meta( $post->ID, '_lbum_testimonial_org_name', true ); 
			?>

			<div class="item">
				<div class="content-text">
				<p style="color:<?php echo $description_color; ?>"><?php echo get_the_content(); ?></p>
				
				</div>

				<div class="images">
					<div class="pic">
						<img alt="<?php echo esc_attr($testimonial_name); ?>" src="<?php echo esc_url($testimonial_image); ?>" />
					</div>
					<div class="author"> 
						<div class="name" style="color:<?php echo esc_attr($name_color); ?>"><?php echo $testimonial_name; ?></div>
						<div class="position" style="color:<?php echo esc_attr($position_color); ?>"><?php echo $testimonial_org_name; ?></div>
					</div>
				</div>
				
			</div>

		<?php endwhile; // end of the loop. ?>
		
		<?php
		endif; 
		wp_reset_postdata();
		?>
	</div>
</div>
<?php endif ?>

<?php 

	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

add_shortcode("lbum_testimonials", "lbum_testimonials");


