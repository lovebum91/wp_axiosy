<?php


function lbum_port_owlslider_js($owlsliderjsid){
	?>
	<script type="text/javascript">

	jQuery(document).ready(function($) {

		$("#owlslider_<?php echo $owlsliderjsid ?>").owlCarousel({
			items : 4,
			lazyLoad : true,
			navigation : true,
			navigationText: [
		  	"<i class='ion-ios-arrow-thin-left'></i>",
		  	"<i class='ion-ios-arrow-thin-right'></i>"
		  	]
			}); 
	});

	</script>

<?php }

// Latest Portfolio

function lbum_latest_portfolio($atts, $content = null) {
	$owlid = rand();
	extract(shortcode_atts(array(
		"introtext" => 'Our work',
		'items'  => '12',
        'orderby' => 'date',
        'order' => 'desc'
	), $atts));
	ob_start();
	?>
   
 	<?php lbum_port_owlslider_js($owlid)?>

	<section class="slider">
			<div class="row">
				<div class="col-lg-12">
					<div class="titlewrap">
						<h2><?php echo $introtext; ?></h2>
					</div>
				</div>
					<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
						<?php
						$args = array(
						    'post_type' => 'portfolio',
							'post_status' => 'publish',
							'ignore_sticky_posts'   => 1,
							//'posts_per_page' => $items
						);

						$portfolios = new WP_Query( $args );

						if ( $portfolios->have_posts() ) : ?>
						            
						    <?php while ( $portfolios->have_posts() ) : $portfolios->the_post(); ?>

		                        <?php
		                        global $post;
		                        $terms = get_the_terms($post->ID, 'lbum_portfoliocategory');
		                        $term_list = '';
		                        $term_list_sep = '';
		                        if (is_array($terms)) {
		                            foreach ($terms as $term) {
		                                $term_list .= $term->slug;
		                                $term_list .= ' ';
		                            }

		                            $arraysep = array();
		                            foreach ($terms as $termsep) {
		                                $arraysep[] = '<span>'.$termsep->slug.'</span>';
		                            }
		                        }

		                        ?>
		                        <div <?php post_class("element-item $term_list"); ?> id="post-<?php the_ID(); ?>">
		                            <div class="lbum-portfolio-thumbnail">
		                                <?php lbum_portfolio_recentthumb(get_the_ID()); ?>
		                                <div class="lbum-portfolio-recent-text-wrap">
		                                    <div class="lbum-portfolio-recent-text-wrap">
		                                        <h2 class="lbum-portfolio-recent-title"><a href="<?php echo esc_url(the_permalink()); ?>" rel="bookmark" title="<?php printf(esc_html__('Permanent Link to %s', 'axiosy'), get_the_title()); ?>"> <?php the_title(); ?></a></h2>
		                                    </div>
		                                    <div class="lbum-portfolio-categories">
		                                        <?php echo implode(', ', $arraysep) ?>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
						    <?php endwhile; // end of the loop. ?>   
						<?php
						endif; 
						wp_reset_postdata();
						?>
			</div>
		</div>
	</section>

    <?php //} ?>

	<?php
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

add_shortcode("lbum_latest_portfolio", "lbum_latest_portfolio");

