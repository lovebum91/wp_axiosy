<?php
// [Icon Box]
function icon_box( $atts, $content = null ){
  extract( shortcode_atts( array(
    'styles' => 'boxstyle01',
    'icon' => '',
    'custom_icon_size' => '',
    'icons_color' => '',
    'icons_bg_color' => 'transparent',
    'icons_border_color' => '',
    'title' => '',
    'title_color' => '',
    'description' => '',
    'des_color' => '',
    'extra_class' => '',
	'animation' => 'none',
	'animation_delay' => '',
	), $atts ) );
	
	if(!empty($extra_class)){
		$extra_class = esc_attr($extra_class);
	}
	//Animation
	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = 'data-delay="'.$animation_delay.'"';
	$animation_style = esc_attr($animation_style);
	// Icon size
	$custom_icon_size_temp = "";
	if(!empty($custom_icon_size)) {
		$custom_icon_size_temp = ' font-size:'.$custom_icon_size;
	}

	$icons_color_temp = ' color: '.$icons_color;
	$icons_bg_color_temp = 'background-color:'.$icons_bg_color;
	$title_color_temp = ' color: '.$title_color;
	$des_color_temp ='color: '.$des_color;
	$icons_border_color_temp = 'border-color: '.$icons_border_color;
	
	//Icon
	$icon = '<i style="'.esc_attr($custom_icon_size_temp).';'.esc_attr($icons_color_temp).';'.esc_attr($icons_bg_color_temp).';'.esc_attr($icons_border_color_temp).'" class="fa fa-'.esc_attr($icon).'"></i>';

	$html = "";
	if($styles == 'boxstyle01'){
		$html .= '<div class="icon-box boxstyle01 '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'>';
		$html .= '<div class="icon">'.$icon.'</div>';
		$html .= '<div class="title" style="'.esc_attr($title_color_temp).'">'.$title.'</div>';
		$html .= '<div class="description" style="'.esc_attr($des_color_temp).'">'.$description.'</div>';
		$html .= '</div>';
	}
	elseif($styles == 'boxstyle02'){
		$html .= '<div class="icon-box boxstyle02 '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'>';
		$html .= '<div class="icon">'.$icon.'</div>';
		$html .= '<div class="title-des"><div class="title" style="'.esc_attr($title_color_temp).'">'.$title.'</div>';
		$html .= '<div class="description" style="'.esc_attr($des_color_temp).'">'.$description.'</div></div>';
		$html .= '</div>';
	}
	elseif($styles == 'boxstyle03'){
		$html .= '<div class="icon-box boxstyle03 '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'>';
		$html .= '<div class="icon">'.$icon.'</div>';
		$html .= '<div class="title-des"><div class="title" style="'.esc_attr($title_color_temp).'">'.$title.'</div>';
		$html .= '<div class="description" style="'.esc_attr($des_color_temp).'">'.$description.'</div></div>';
		$html .= '</div>';
	}
	elseif($styles == 'boxstyle04'){
		$html .= '<div class="icon-box boxstyle04 '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'>';
		$html .= '<div class="icon">'.$icon.'</div>';
		$html .= '<div class="title-des"><div class="title" style="'.esc_attr($title_color_temp).'">'.$title.'</div>';
		$html .= '<div class="description" style="'.esc_attr($des_color_temp).'">'.$description.'</div></div>';
		$html .= '</div>';
	}
	else{
		$html .= '<div class="icon-box boxstyle05 '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'>';
		$html .= '<div class="icon" style="'.esc_attr($icons_border_color_temp).'">'.$icon.'</div>';
		$html .= '<div class="title-des"><div class="title" style="'.esc_attr($title_color_temp).'">'.$title.'</div>';
		$html .= '<div class="description" style="'.esc_attr($des_color_temp).'">'.$description.'</div></div>';
		$html .= '</div>';
	}
	return $html;
}
add_shortcode('icon_box', 'icon_box');
