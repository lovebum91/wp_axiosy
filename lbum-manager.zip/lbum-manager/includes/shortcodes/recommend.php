<?php

function lbum_owlslider_js_recommend($owlsliderjsid){
	?>
	<script type="text/javascript">

	jQuery(document).ready(function($) {

		$("#owlslider_<?php echo $owlsliderjsid ?>").owlCarousel({
			/*autoPlay: 4000,*/ 
			singleItem : true,
			navigation : true,
			pagination : true,
			stopOnHover : true,
			navigationText: [
			  	"<i class='ion-ios-arrow-thin-left'></i>",
			  	"<i class='ion-ios-arrow-thin-right'></i>",
			  	]
		}); 
	});

	</script>
<?php }

// lbum_recommends 

function lbum_recommends($atts, $content = null) {
	$owlid = rand();
	extract(shortcode_atts(array(
		"posts" => '10',
		"category" => '',
		'bg_color' => '',
		"animation" => "none",
		'animation_delay' => '',
	), $atts));
	
	//Animation
	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = '';

	ob_start();
	?>
        
<?php lbum_owlslider_js_recommend($owlid)?>

<?php if(!empty($animation) && $animation !="none"){?>
	<div class="lbum_recommends_wrap slider <?php echo esc_attr($animation_style) ?>"  <?php echo $data_animation_style; echo $animation_delay; ?>>
<?php }else { ?>
	<div class="lbum_recommends_wrap slider">
<?php }?>

	<div class="row">
		<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
			<?php
				$args = array(
								'post_type' 			=> 'recommends',
								'post_status' 			=> 'publish',
								'ignore_sticky_posts'   => 1,
								'posts_per_page' 		=> $posts,
								'tax_query' 			=> array(
									array(
										'taxonomy' 		=> 'lbum_recommendcategory',
										'terms' 		=> array(esc_attr($category)),
										'field' 		=> 'slug',
										'operator' 		=> 'IN'
									)
								),	
				);

				$recommends = new WP_Query( $args );

				if ( $recommends->have_posts() ) : ?>
				<?php while ( $recommends->have_posts() ) : $recommends->the_post(); ?>

				<?php 
				global $post;
				$title 		= get_post_meta( $post->ID, '_lbum_title', true ); 
				$sub_title 	= get_post_meta( $post->ID, '_lbum_sub_title', true ); 
				$logo_url 		= get_post_meta( $post->ID, '_lbum_logo_url', true ); 
				$logo_img 	= get_post_meta( $post->ID, '_lbum_logo_image', true ); 
				?>

				<div class="item">
					<div class="recommend-img">
						<a href="<?php echo esc_url($logo_url); ?>">
							<img alt="logo" src="<?php echo esc_url($logo_img); ?>">
						</a>
					</div>
					<div class="recommend-text" style="background-color:<?php echo esc_attr($bg_color);?>">
						<a href="<?php echo esc_url($logo_url); ?>">
							<span class="recommend-title"><?php echo $title; ?></span>
							<span class="recommend-subtitle"><?php echo $sub_title; ?></span>
						</a>
					</div>
				</div>

			<?php endwhile; // end of the loop. ?>
			
			<?php
			endif; 
			wp_reset_postdata();
			?>

		</div>
	</div>
</div>

<?php 

	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

add_shortcode("lbum_recommends", "lbum_recommends");


