<?php
// [button]
function blank_spacer( $atts, $content = null ){
  extract( shortcode_atts( array(
    'height' => '',
    'class' => ''
  ), $atts ) );

return '<div style="height:'.esc_attr($height).';" class="blank-spacer '.esc_attr($class).'"></div>';
}
add_shortcode('blank_spacer', 'blank_spacer');
