<?php
// [list_categories]
function list_categories( $atts, $content = null ){
	extract( shortcode_atts( array(
	    'introtext' => 'Product Categories',
		"animation" => "none",
		'animation_delay' => '',
	), $atts ) );
		//Animation
	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = '';

	ob_start();

	$html ='';

	$taxonomy     = 'product_cat';
	$orderby      = 'name';  
	$show_count   = 1;      // 1 for yes, 0 for no
	$pad_counts   = 0;      // 1 for yes, 0 for no
	$hierarchical = 0;      // 1 for yes, 0 for no  
	$title        = '';  
	$empty        = 1;

	$args = array(
	     'taxonomy'     => $taxonomy,
	     'orderby'      => $orderby,
	     'show_count'   => $show_count,
	     'pad_counts'   => $pad_counts,
	     'hierarchical' => $hierarchical,
	     'title_li'     => $title,
	     'hide_empty'   => $empty
	);
	$all_categories = get_categories( $args );
?>
	<div class="lbum-categories widget woocommerce widget_product_categories <?php echo esc_attr($animation_style); ?>" <?php echo $data_animation_style; echo $animation_delay; ?>>
	<?php if(!empty($introtext)) : ?>
	<div class="titlewrap">
		<h2><?php echo $introtext; ?></h2>
	</div>
	<?php endif ?>
	<ul class="product-categories">
	<?php foreach ($all_categories as $cat) {
		if($cat->category_parent == 0) {
		    $category_id = $cat->term_id; ?>
		    
		    <li class="cat-item cat-parent cat-item-<?php echo esc_attr($category_id) ?>"><a href=" <?php echo get_term_link($cat->slug, 'product_cat') ?> "><?php echo $cat->name ?></a>

		    <?php
		    $args2 = array(
		            'taxonomy'     => $taxonomy,
		            'child_of'     => 1,
		            'parent'       => $category_id,
		            'orderby'      => $orderby,
		            'show_count'   => $show_count,
		            'pad_counts'   => $pad_counts,
		            'hierarchical' => $hierarchical,
		            'title_li'     => $title,
		            'hide_empty'   => $empty
		    );
		    $sub_cats = get_categories( $args2 );
		    if($sub_cats) { ?>
		    	<ul class="children">
		        <?php foreach($sub_cats as $sub_category) { ?>
		        	<li class="cat-item cat-item-<?php echo $sub_category -> $category_id ?>">
		        	<a href="<?php echo esc_url(get_term_link($sub_category->slug, 'product_cat')) ?>"> <?php echo $sub_category->name ?></a>
		        	</li>
		        <?php } ?>    
		        </ul>
		    <?php } ?>  

		    </li>
		<?php } ?>         
	<?php } ?>    
	</ul></div>

<?php 

	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

add_shortcode("list_categories", "list_categories");