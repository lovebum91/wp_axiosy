<?php
// [Icon List]
function icon_list( $atts, $content = null ){
  extract( shortcode_atts( array(
    'styles' => 'iconlistnormal',
    'icon' => '',
    'custom_icon_size' => '',
    'icons_color' => '#202020',
    'icons_bg_color' => 'transparent',
    'text' => '',
    'text2' => '',
    'txt_color' => '#202020',
    'extra_class' => '',
	'animation' => 'none',
	'animation_delay' => '',
	), $atts ) );
	
	if(!empty($extra_class)){
		$extra_class = esc_attr($extra_class);
	}

	//Animation
	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = 'data-delay="'.$animation_delay.'"';
	$animation_style = esc_attr($animation_style);

	// Icon size
	$custom_icon_size_temp = "";
	if(!empty($custom_icon_size)) {
		$custom_icon_size_temp = ' font-size:'.$custom_icon_size;
	}

	$icons_color_temp = ' color:'.$icons_color;
	$txt_color_temp = ' color:'.$txt_color;
	$icons_bg_color_temp = 'background-color:'.$icons_bg_color;

	//Icon
	$icon = '<i style="'.esc_attr($custom_icon_size_temp).';'.esc_attr($icons_color_temp).';'.esc_attr($icons_bg_color_temp).'" class="fa fa-'.esc_attr($icon).'"></i>';

	$html = "";
	if($styles == 'iconlistnormal'){
		$html .= '<div class="icon-list iconlistnormal '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'>';
		$html .= '<div class="content">'.$icon.'<span style="'.esc_attr($txt_color_temp).'">'.$text.'</span></div>';
		$html .= '</div>';
	}
	elseif($styles == 'iconlistround'){
		$html .= '<div class="icon-list iconlistround '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'>';
		$html .= '<div class="content">'.$icon.'<span style="'.esc_attr($txt_color_temp).'">'.$text.'</span></div>';
		$html .= '</div>';
	}
	elseif($styles == 'iconlistroundspecial'){
		$html .= '<div class="icon-list iconlistroundspecial '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'>';
		$html .= '<div class="content">'.$icon.'<p style="'.esc_attr($txt_color_temp).'">'.$text.'<br/>'.$text2.'</p></div>';
		$html .= '</div>';
	}
	else{
		$html .= '<div class="icon-list iconlistsquare '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'>';
		$html .= '<div class="content">'.$icon.'<span style="'.esc_attr($txt_color_temp).'">'.$text.'</span></div>';
		$html .= '</div>';
	}
	return $html;
}
add_shortcode('icon_list', 'icon_list');
