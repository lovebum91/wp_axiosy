<?php
// [Countdown]
function lbum_countdown_shortcode($atts, $content = null){
	extract(shortcode_atts(array(
		"date_time" 			=> '',
		"txt_color"				=> '',
		"border_color"			=> '',
	),$atts));

	$border = "";
	if(!empty($border_color)){
		$border .= ";border-color:".$border_color;
		$border = esc_attr($border);
	}

	$html = "";
	$html .='<script>';
	$html .='jQuery(document).ready(function(){';
	$html .="jQuery('#cicle-cd').countdown('".esc_attr($date_time)."', function(event) {";
	$html .="jQuery(this).html(event.strftime('<div class=cicle-items-wrap><ul class=cicle-items style= color:".esc_attr($txt_color)."><li style=".$border."><span>%D</span> <div>DAYS</div></li><li style=".$border."><span>%H</span><div>HRS</div></li><li style=".$border."><span>%M </span><div>MIN</div> </li><li style=".$border."><span>%S </span><div>SEC</div></li></ul></div>'))";
	$html .='})';
	$html .='})';
	$html .='</script>';
	$html .= "<div class='cicle-cd-wrap'><div id='cicle-cd'></div></div>";
	return $html;
}
add_shortcode("lbum_countdown","lbum_countdown_shortcode");

