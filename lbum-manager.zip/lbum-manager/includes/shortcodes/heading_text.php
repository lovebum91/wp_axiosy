<?php
// [headding]
function heading_text( $atts, $content = null ){
  extract( shortcode_atts( array(
    'title_tag' => 'h2',
    'heading_style' => 'normal',
    'custom_size' => '',
    'heading_color' => '#202020',
    'text' => '',
    'text_des_color' => '',
    'text_des' => '',
    'text_align' => '',
    'border_bottom_color' => '',
    'extra_class' => '',
	'animation' => 'none',
	'animation_delay' => '',
	), $atts ) );
	
	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = 'data-delay="'.$animation_delay.'"';
	$animation_style = esc_attr($animation_style);

	$html = "";
	$_size = "";
	
	if(!empty($extra_class)){
		$extra_class = esc_attr($extra_class);
	}

	if(!empty($custom_size)) {
		$_size = esc_attr(' font-size:'.$custom_size.'px;');
	}

	//
	$text_align_temp = '';
	if($text_align == 'text_center'){
		$text_align_temp = 'margin-right: auto; margin-left: auto;';
	}
	elseif($text_align == 'text_right'){
		$text_align_temp = 'float: right;';
	}

	if($heading_style == 'style01'){
		$html .= '<div class="lbum-heading style01 '.esc_attr($text_align).' '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'><'.$title_tag.' style="color:'.$heading_color.';'.$_size.'">';
		$html .= $text;
		$html .= '</'.$title_tag.'></div>';
	}
	else if($heading_style == 'style02'){
		$html .= '<div class="lbum-heading style02 '.esc_attr($text_align).' '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'><'.$title_tag.' style="color:'.$heading_color.';'.$_size.';border-color:'.$border_bottom_color.'">';
		$html .= $text;
		$html .= '</'.$title_tag.'>';
		$html .= '<div class="title-des" style="color:'.esc_attr($text_des_color).';">'.$text_des.'</div></div>';

	}
	else if($heading_style == 'style03'){
		$html .= '<div class="lbum-heading style03 '.esc_attr($text_align).' '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'><'.$title_tag.' style="color:'.$heading_color.';'.$_size.'">';
		$html .= $text;
		$html .= '<span class="position_left border" style="margin-top: -1px;border-bottom-width: 1px;"></span><span class="position_right border" style="margin-top: -1px;border-bottom-width: 1px;"></span>';
		$html .= '</'.$title_tag.'></div>';
	}
	else if($heading_style == 'style04'){
		$html .= '<div class="lbum-heading style04 '.esc_attr($text_align).' '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'><'.$title_tag.' style="color:'.$heading_color.';'.$_size.'">';
		$html .= $text;
		$html .= '</'.$title_tag.'>';
		$html .= '<div class="border-double" style="'.esc_attr($text_align_temp).'"><span style="border-color:'.$heading_color.';" class="one-line"></span><span style="border-color:'.$heading_color.';" class="two-line"></span></div>';
		$html .= '</div>';
	}
	else if($heading_style == 'style05'){
		$html .= '<div class="lbum-heading style05 '.esc_attr($text_align).' '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'><'.$title_tag.' style="color:'.$heading_color.';border-color:'.$border_bottom_color.';'.$_size.'">';
		$html .= $text;
		$html .= '</'.$title_tag.'>';
		$html .= '<div class="title-des" style="color:'.esc_attr($text_des_color).';">'.$text_des.'</div></div>';
	}
	else{
		$html .= '<div class="lbum-heading '.esc_attr($text_align).' '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'><'.$title_tag.' style="color:'.$heading_color.';'.$_size.'">';
		$html .= $text;
		$html .= '</'.$title_tag.'>';
		$html .= '<div class="title-des" style="color:'.esc_attr($text_des_color).';">'.$text_des.'</div></div>';
	}
	return $html;
}
add_shortcode('heading_text', 'heading_text');
