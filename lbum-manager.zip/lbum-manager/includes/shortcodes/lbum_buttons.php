<?php

//lbum_buttons
function lbum_buttons($atts, $content = null) {
    $args = array(
        "styles"                    => "",
        "size"                      => "",
        "text"                      => "",
        "icon"                      => "",
        "link"                      => "",
        "target"                    => "_self",
        "color"                     => "",
        "background_color"			=> "",
        "border_color"              => "",
        "margin"					=> "",
        "border_radius"				=> ""
    );

    extract(shortcode_atts($args, $atts));

    if($target == ""){
        $target = "_self";
    }

    //init variables
    $html  = "";
    $button_classes = "lbum-button";
    $button_styles  = "";
    $add_icon       = "";
    $data_attr      = "";

    if($size != "") {
        $button_classes .= " {$size}";
    }

    if($color != ""){
        $button_styles .= 'color: '.$color.'; ';
    }

    if($border_color != "" && $background_color == ""){
        $button_styles .= 'border: 2px solid '.$border_color.'; ';
        $button_classes .= ' btn-link';
    }

    if($background_color != "" ) {
        $button_styles .= "background-color: {$background_color};";
        $button_classes .= ' btn-back';
    }

    if($icon != "" && $styles == "txticon"){
        $add_icon .= '<i class="fa fa-'.$icon.'"></i>';
    }

    if($margin != ""){
        $button_styles .= 'margin: '.$margin.'; ';
    }

	if($border_radius != ""){
		$button_styles .= 'border-radius: '.$border_radius.'px;-moz-border-radius: '.$border_radius.'px;-webkit-border-radius: '.$border_radius.'px; ';
	}

    $html .=  '<a href="'.esc_url($link).'" target="'.esc_attr($target).'" '.$data_attr.' class="'.esc_attr($button_classes).'" style="'.esc_attr($button_styles).'">'.$text.$add_icon.'</a>';

    return $html;
}
add_shortcode('lbum_button', 'lbum_buttons');