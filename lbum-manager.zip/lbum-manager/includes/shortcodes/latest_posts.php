<?php

function lbum_owlslider_js_posts($owlsliderjsid, $count_items){
	?>
	<script type="text/javascript">

	jQuery(document).ready(function($) {
		$("#owlslider_<?php echo $owlsliderjsid ?>").owlCarousel({
			items : <?php echo $count_items?>,
			itemsDesktop : [1000,2], //5 items between 1000px and 901pxs
          	itemsDesktopSmall : [950,2], // 2 items betweem 900px and 601px
          	itemsTablet: [650,1], //2 items between 600 and 0;
          	itemsMobile : [320,1],
			lazyLoad : true,
			navigation : true,
			pagination: false,
			rewindNav: false,
			slideSpeed: 500,
			navigationText: [
		  	"<i class='ion-ios-arrow-thin-left'></i>",
		  	"<i class='ion-ios-arrow-thin-right'></i>"
		  	]
		}); 
	});

	</script>
<?php }

function lbum_owlslider_js_posts_style04($owlsliderjsid, $count_items){
	?>
	<script type="text/javascript">

	jQuery(document).ready(function($) {
		$("#owlslider_<?php echo $owlsliderjsid ?>").owlCarousel({
			items : <?php echo $count_items?>,
			itemsDesktop : [1200,3], //5 items between 1000px and 901pxs
          	itemsDesktopSmall : [950,2], // 2 items betweem 900px and 601px
          	itemsTablet: [780,1], //2 items between 600 and 0;
          	itemsMobile : [320,1],
			lazyLoad : true,
			navigation : true,
			pagination: false,
			rewindNav: false,
			slideSpeed: 500,
			navigationText: [
		  	"<i class='ion-ios-arrow-thin-left'></i>",
		  	"<i class='ion-ios-arrow-thin-right'></i>"
		  	]
		}); 
	});

	</script>
<?php }

// Latest News 

function lbum_latest_posts($atts, $content = null) {
	global $woocommerce;
	$owlid = rand();
	extract(shortcode_atts(array(
    	"introtext" => 'From the blog',
    	'styles' => 'blogstyle01',
		"posts" => '8',
		'display_items'  => '3',
		"category" => '',
		'text_algins' => 'center',
		"animation" => "none",
		'animation_delay' => '',
	), $atts));

	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = 'data-delay="'.$animation_delay.'"';

	$text_algin = $text_algins;
	ob_start();
	?>

<?php if($styles == 'blogstyle01'): ?>      
<?php lbum_owlslider_js_posts($owlid, $display_items)?>
<div <?php echo $data_animation_style; echo $animation_delay; ?> class="slider blogstyle01 <?php echo esc_attr($animation_style) ?>">
	<div class="row">
		<div class="col-lg-12">
			<?php if(!empty($introtext)) : ?>
			<div class="titlewrap">
				<h2><?php echo $introtext; ?></h2>
			</div>
			<?php endif ?>
		</div>
			<div class="lbum-articles">
				<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
					<?php
						$args = array(
							'post_status' => 'publish',
							'post_type' => 'post',
							'category_name' => $category,
							'posts_per_page' => $posts
						);

					$recentPosts = new WP_Query( $args );

					if ( $recentPosts->have_posts() ) : ?>
					        
					<?php while ( $recentPosts->have_posts() ) : $recentPosts->the_post(); ?>
					  <div class="item">
						    <div class="thumb">
							    <a href="<?php echo esc_url(the_permalink()) ?>"><?php the_post_thumbnail('lbum-hp-latest-posts'); ?></a>
						    </div><!--/.thumb -->
							<div class="description" style="text-align:<?php echo $text_algin; ?>">
						  		<h3><a href="<?php echo esc_url(the_permalink()) ?>"><?php the_title(); ?></a></h3>

							    <div class="date">
								    <i class="fa fa-calendar" aria-hidden="true"></i><span class="day-month-year"><?php echo get_the_time('F j, Y', get_the_ID()); ?></span>
							    </div>
						  			<p class="comments"><i class="fa fa-commenting-o" aria-hidden="true"></i><?php echo get_comments_number( get_the_ID() ); ?> comments</p>
						  		<?php 
						  		the_excerpt();
						  		?>
						  	</div>
					  </div>
					<?php endwhile; // end of the loop. ?>
							    
					<?php
					endif; 
					wp_reset_postdata();
					?>
				</div>
			</div>
		</div>
</div>
<?php elseif($styles == 'blogstyle02'): ?>
<?php lbum_owlslider_js_posts($owlid, $display_items)?>
<div <?php echo $data_animation_style; echo $animation_delay; ?> class="slider blogstyle02 <?php echo esc_attr($animation_style) ?>">
	<div class="row">
		<div class="col-lg-12">
			<?php if(!empty($introtext)) : ?>
			<div class="titlewrap">
				<h2><?php echo $introtext; ?></h2>
			</div>
			<?php endif ?>
		</div>
		<div class="lbum-articles">
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
				<?php
					$args = array(
						'post_status' => 'publish',
						'post_type' => 'post',
						'category_name' => $category,
						'posts_per_page' => $posts
					);

				$recentPosts = new WP_Query( $args );

				if ( $recentPosts->have_posts() ) : ?>
				        
				<?php while ( $recentPosts->have_posts() ) : $recentPosts->the_post(); ?>
				  <div class="item">
						<div class="thumb">						   
						    <a class="link" href="<?php echo esc_url(the_permalink()) ?>"><?php the_post_thumbnail('lbum-hp-latest-posts'); ?></a>
						    <div class="link-icon">
						    	<a href="<?php echo esc_url(the_permalink()) ?>"><i class="fa fa-share"></i></a>
						    </div>
						</div><!--/.thumb -->
					 	
					 	<div class="description" style="text-align:<?php echo esc_attr($text_algin);?>;">
					  		<div class="date">
					  			<div class="month"><?php echo get_the_time('M', get_the_ID()); ?></div>
							    <div class="day"><?php echo get_the_time('j', get_the_ID()); ?></div>
						    </div>
					  		<h3><a href="<?php echo esc_url(the_permalink()) ?>"><?php the_title(); ?></a></h3>
					  		<p class="comments"><i class="fa fa-comments-o" aria-hidden="true"></i><?php echo get_comments_number( get_the_ID() ); ?> <?php esc_html_e( 'comments', 'axiosy' ); ?></p>
					  		<div class="readmore"><a href="<?php echo esc_url(the_permalink()) ?>"><?php esc_html_e( 'Readmore', 'axiosy' ); ?><i class="ion-ios-arrow-thin-right"></i></a></div>
				  		</div>
				  </div>
				<?php endwhile; // end of the loop. ?>
						    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
		</div>
</div>
<?php elseif($styles == 'blogstyle03'): ?>
<?php lbum_owlslider_js_posts($owlid, $display_items)?>
<div <?php echo $data_animation_style; echo $animation_delay; ?> class="slider blogstyle03 <?php echo esc_attr($animation_style) ?>">
	<div class="row">
		<div class="col-lg-12">
			<?php if(!empty($introtext)) : ?>
			<div class="titlewrap">
				<h2><?php echo $introtext; ?></h2>
			</div>
			<?php endif ?>
		</div>
			<div class="lbum-articles">
				<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
					<?php
						$args = array(
							'post_status' => 'publish',
							'post_type' => 'post',
							'category_name' => $category,
							'posts_per_page' => $posts
						);

					$recentPosts = new WP_Query( $args );

					if ( $recentPosts->have_posts() ) : ?>
					        
					<?php while ( $recentPosts->have_posts() ) : $recentPosts->the_post(); ?>
					  <div class="item">
						  <div class="thumb">
							    <a class="link" href="<?php echo esc_url(the_permalink()) ?>"><?php the_post_thumbnail('lbum-hp-latest-posts'); ?></a>
							    <div class="link-icon">
						    		<a href="<?php echo esc_url(the_permalink()) ?>"><i class="fa fa-share"></i></a>
						    	</div>
						  </div><!--/.thumb -->
							 
						 <div class="description">
					  		<h3><a href="<?php echo esc_url(the_permalink()) ?>"><?php the_title(); ?></a></h3>
					  		
					  		<div class="content-left">
					  			<p class="comments"><?php echo get_comments_number( get_the_ID() ); ?> <?php esc_html_e( 'comments', 'axiosy' ); ?></p>
					  			/
					  			<div class="date">
								    <span class="month"><?php echo get_the_time('M, j', get_the_ID()); ?></span>
							    	<span class="year"><?php echo get_the_time('Y', get_the_ID()); ?></span>
							    </div>
							    /
							    <div class="readmore">
							    	<a href="<?php echo esc_url(the_permalink()) ?>"><?php esc_html_e( 'Readmore', 'axiosy' ); ?></a>
							    </div>
					  		</div>
					  		<div class="content-right">
						  		<?php 
						  		the_excerpt();
						  		?>
					  		</div>
				  		</div>
					  </div>
					<?php endwhile; // end of the loop. ?>
							    
					<?php
					endif; 
					wp_reset_postdata();
					?>
				</div>
			</div>
		</div>
</div>
<?php elseif($styles == 'blogstyle04'): ?>
<?php lbum_owlslider_js_posts_style04($owlid, 4)?>
<div <?php echo $data_animation_style; echo $animation_delay; ?> class="slider blogstyle04 <?php echo esc_attr($animation_style) ?>">
	<div class="row">
		<div class="col-lg-12">
			<?php if(!empty($introtext)) : ?>
			<div class="titlewrap">
				<h2><?php echo $introtext; ?></h2>
			</div>
			<?php endif ?>
		</div>
			<div class="lbum-articles">
				<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
					<?php
						$args = array(
							'post_status' => 'publish',
							'post_type' => 'post',
							'category_name' => $category,
							'posts_per_page' => $posts
						);

					$recentPosts = new WP_Query( $args );
					if ( $recentPosts->have_posts() ) : 
					$i = 1; ?>      
					<?php while ( $recentPosts->have_posts() ) : $recentPosts->the_post(); ?>
						<?php if($i % 2 != 0) : ?>
						  	<div class="item" >
								<div class="item-wrap content-bottom">
									<div class="thumb thumb-left">
										<a class="link" href="<?php echo esc_url(the_permalink()) ?>"><?php the_post_thumbnail('lbum-hp-latest-posts'); ?></a>
									</div><!--/.thumb -->
										 
									<div class="description des-right" style="text-align:<?php echo esc_attr($text_algin); ?>;">
								  		<h3><a href="<?php echo esc_url(the_permalink()) ?>"><?php the_title(); ?></a></h3>
								  		<div class="cont-right">
									  		<?php 
									  		the_excerpt();
									  		?>
									  		<div class="date">
										    	<i class="fa fa-calendar" aria-hidden="true"></i><span class="day-month-year"><?php echo get_the_time('M j, Y', get_the_ID()); ?></span>
									    	</div>
								  			<p class="comments"><i class="fa fa-commenting-o" aria-hidden="true"></i><?php echo get_comments_number( get_the_ID() ); ?></p>
								  		</div>
							  		</div>
						  		</div> <!--item-wrap-->
						  	</div> <!--item-->
						  	<?php $i ++; ?>
						<?php else: ?>
							<div class="item" >
								<div class="item-wrap content-top"> 
									<div class="description des-right" style="text-align:<?php echo esc_attr($text_algin); ?>;">
								  		<h3><a href="<?php echo esc_url(the_permalink()) ?>"><?php the_title(); ?></a></h3>
								  		<div class="cont-right">
									  		<?php 
									  		the_excerpt();
									  		?>
									  		<div class="date">
										    	<i class="fa fa-calendar" aria-hidden="true"></i><span class="day-month-year"><?php echo get_the_time('M j, Y', get_the_ID()); ?></span>
									    	</div>
								  			<p class="comments"><i class="fa fa-commenting-o" aria-hidden="true"></i><?php echo get_comments_number( get_the_ID() ); ?></p>
								  		</div>
							  		</div>
							  		<div class="thumb thumb-left">
										<a class="link" href="<?php echo esc_url(the_permalink()) ?>"><?php the_post_thumbnail('lbum-hp-latest-posts'); ?></a>
									</div><!--/.thumb -->
						  		</div> <!--item-wrap-->
						  	</div> <!--item-->
						  	<?php $i --; ?>
						<?php endif; ?>

					<?php endwhile; // end of the loop. ?>
							    
					<?php
					endif; 
					wp_reset_postdata();
					?>
				</div>
			</div>
		</div>
</div>
<?php else: ?>
<?php lbum_owlslider_js_posts($owlid, $display_items)?>
<div <?php echo $data_animation_style; echo $animation_delay; ?> class="slider blogstyle05 <?php echo esc_attr($animation_style) ?>">
	<div class="row">
		<div class="col-lg-12">
			<?php if(!empty($introtext)) : ?>
			<div class="titlewrap">
				<h2><?php echo $introtext; ?></h2>
			</div>
			<?php endif ?>
		</div>
		<div class="lbum-articles">
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
				<?php
					$args = array(
						'post_status' => 'publish',
						'post_type' => 'post',
						'category_name' => $category,
						'posts_per_page' => $posts
					);

				$recentPosts = new WP_Query( $args );

				if ( $recentPosts->have_posts() ) : ?>
				        
				<?php while ( $recentPosts->have_posts() ) : $recentPosts->the_post(); ?>
				  <div class="item">
						<div class="thumb">
						    <div class="date">
							    <span class="month"><?php echo get_the_time('M, j', get_the_ID()); ?></span>
							    <span class="year"><?php echo get_the_time('Y', get_the_ID()); ?></span>
						    </div>
						    <a class="link" href="<?php echo esc_url(the_permalink()) ?>"><?php the_post_thumbnail('lbum-hp-latest-posts'); ?></a>
						    <div class="link-icon">
						    	<a href="<?php echo esc_url(the_permalink()) ?>"><i class="fa fa-share"></i></a>
						    </div>
						</div><!--/.thumb -->
					 	
					 	<div class="description" style="text-align:<?php echo esc_attr($text_algin);?>;">
					  		<h3><a href="<?php echo esc_url(the_permalink()) ?>"><?php the_title(); ?></a></h3>
					  		<?php 
					  		the_excerpt();
					  		?>
					  		<p class="comments"><i class="fa fa-comments-o" aria-hidden="true"></i><?php echo get_comments_number( get_the_ID() ); ?> comments</p>
				  		</div>
				  </div>
				<?php endwhile; // end of the loop. ?>
						    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
		</div>
</div>
<?php endif ?>

<?php 
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

add_shortcode("lbum_latest_posts", "lbum_latest_posts");


