<?php
// [tabgroup]
function lbum_tabgroup( $params, $content = null ) {
	$GLOBALS['tabs'] = array();
	$GLOBALS['tab_count'] = 0;
	$i = 1;
	$randomid = rand();

	extract(shortcode_atts(array(
		'title' => '',
		'style'	=> 'style_1',
	), $params));

	$content = do_shortcode($content);
	if( is_array( $GLOBALS['tabs'] ) ){
	
		foreach( $GLOBALS['tabs'] as $tab ){
			if($i == 1){
				$tabs[] = '<li class="tab active"><a data-toggle="pill" href="#panel'.esc_attr($randomid).esc_attr($i).'">'.$tab['title'].'</a></li>';
				$panes[] = '<div class="tab-pane fade in active" id="panel'.esc_attr($randomid).esc_attr($i).'"><div>'.do_shortcode($tab['content']).'</div></div>';
			}
			else{
				$tabs[] = '<li class="tab"><a data-toggle="pill" href="#panel'.$randomid.$i.'">'.$tab['title'].'</a></li>';
				$panes[] = '<div class="tab-pane fade" id="panel'.esc_attr($randomid).esc_attr($i).'"><div>'.do_shortcode($tab['content']).'</div></div>';
			}
			$i++;
		}
		if(!empty($title)){
			$_title = '<h3>'.$title.'</h3>';
		}else {
			$_title = '';
		}
		if($style=="style_1"){
		$return = '
			<div class="tabbed-content shortcode-tabgroup">
				'.$_title.'
				<ul class="tabs nav nav-pills">'.implode( "\n", $tabs ).'</ul><div class="tab-content">'.implode( "\n", $panes ).'</div></div>';
		}elseif($style=="style_2"){
		$return = '
			<div class="tabbed-content2 shortcode-tabgroup">
				'.$_title.'
				<ul class="tabs nav nav-pills">'.implode( "\n", $tabs ).'</ul><div class="tab-content">'.implode( "\n", $panes ).'</div></div>';
		}else{
		$return = '
			<div class="tabbed-content3 shortcode-tabgroup">
				'.$_title.'
				<ul class="tabs nav nav-pills">'.implode( "\n", $tabs ).'</ul><div class="tab-content">'.implode( "\n", $panes ).'</div></div>';
		}
	}
	return $return;
}

function lbum_tab( $params, $content = null) {
	extract(shortcode_atts(array(
			'title' => ''
	), $params));
	
	$x = $GLOBALS['tab_count'];
	$GLOBALS['tabs'][$x] = array( 'title' => sprintf( $title, $GLOBALS['tab_count'] ), 'content' =>  $content );
	$GLOBALS['tab_count']++;
}


add_shortcode('lbum_tabgroup', 'lbum_tabgroup');
add_shortcode( 'lbum_tab', 'lbum_tab' );

?>