<?php
//lbum_image
function lbum_image($atts, $content = null) {
    $args = array(
        "styles"                    => "",
        "src_img"                   => "",
        "title_text"                   => "",
        "title_color"                   => "",
        "link_text"                   => "",
        "link"                   => "",
        "target"                    => "_self",
        "link_color"                   => "",
        "text_content"                   => "",
        "text_content_color"                   => "",
        'animation' => 'none',
        'animation_delay' => '',
    );

    extract(shortcode_atts($args, $atts));

    $animation_style = "";
    $data_animation_style = "";
    if ($animation !== "none") {
        $animation_style = 'animate';
        $data_animation_style = 'data-animate="' . $animation .'"';
    }
    $animation_delay = 'data-delay="'.$animation_delay.'"';
    $animation_style = esc_attr($animation_style);

    $background_image_source = "";
    $src_image = "";
    if ($src_img) {
        $background_image_source = wp_get_attachment_image_src($src_img, '');
        $src_image = esc_url($background_image_source[0]);
    }

    $link = esc_url($link);
    //init variables
    $html  = "";

    $html .= '<div class="lbum-single-image style-image01 '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'>';
    $html .= '<div class="image-wrap"><div class="img-responsive"><a target="'.$target.'" href="'.$link.'"><img src="'.$src_image.'" alt="'.$link_text.'"/></a>';
    $html .= '<div class="text-content" style="color:'.$text_content_color.';">'.$text_content.'</div></div></div>';
    $html .= '<div class="text-wrap"><div class="title_text" style="color:'.$title_color.';">'.$title_text.'</div>';
    if(!empty($link_text))
        $html .= '<a class="link" href="'.$link.'" target="'.$target.'" style="color:'.$link_color.';">'.$link_text.' <i class="ion-ios-arrow-thin-right"></i></a>';
    $html .= '</div></div>';
    
    return $html;
}
add_shortcode('lbum_image', 'lbum_image');