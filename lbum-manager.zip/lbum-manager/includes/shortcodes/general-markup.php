<?php

// [lbum_dropcap]
if ( !function_exists( 'lbum_dropcap' ) ) :

    function lbum_dropcap( $atts, $content = null ) {
        extract( shortcode_atts( array(
            'style' => 'normal',
            'font_size' => '50px'
                        ), $atts ) );

        return "<span class=\"lbum-dropcap lbum-droplbum--$style\" style=\"font-size: $font_size; line-height: $font_size; width: $font_size; height: $font_size;\">" . do_shortcode( $content ) . "</span>";
    }

    add_shortcode( 'lbum_dropcap', 'lbum_dropcap' );
endif;

// [lbum_divider]
if ( !function_exists( 'lbum_divider' ) ) :

    function lbum_divider( $atts, $content = null ) {
        extract( shortcode_atts( array(
            'style' => 'plain',
			'color' => '#e2e2e2',
			'height' => '2px'
                        ), $atts ) );
        return '<hr class="lbum-divider lbum-divider-' . esc_attr($style) . '" style="background: '.$color.';height: '.$height.'">';
    }

    add_shortcode( 'lbum_divider', 'lbum_divider' );
endif;


/* Person Profile shortcode */

if ( !function_exists( 'lbum_person' ) ) {

    function lbum_person( $atts, $content = null ) {
        $args = array(
            "person_img" => "",
            "person_name" => "",
            "person_title" => "",
            "person_desc" => "",
            "person_social_icon_1" => "",
            "person_social_icon_1_url" => "",
            "person_social_icon_2" => "",
            "person_social_icon_2_url" => "",
            "person_social_icon_3" => "",
            "person_social_icon_3_url" => "",
            "person_social_icon_4" => "",
            "person_social_icon_4_url" => "",
            "person_social_icon_5" => "",
            "person_social_icon_5_url" => "",
        );

        extract( shortcode_atts( $args, $atts ) );
        if ( is_numeric( $person_img ) ) {
            $person_img_src = wp_get_attachment_url( $person_img );
        } else {
            $person_img_src = $person_img;
        }

        $output = "<div class='lbum-person'>";
        $output .= "<div class='lbum-person-inner'>";
        if ( $person_img != "" ) {
            $output .= "<div class='lbum-person-img'>";
            $output .= "<img src='$person_img_src' alt='' />";
            $output .= "</div>";
        }
        $output .= "<div class='lbum-person-text'>";
        $output .= "<div class='lbum-person-text-inner'>";
        $output .= "<div class='lbum-team-title-container'>";
        $output .= "<h4 class='lbum-person-name'>";
        $output .= $person_name;
        $output .= "</h4>";
        if ( $person_title != "" ) {
            $output .= "<span class='lbum-person-title'>" . $person_title . "</span>";
        }
        $output .= "</div>";
        $output .= "<p class='lbum-person-desc'>" . $person_desc . "</p>";
        $output .= "</div>";
        $output .= "<div class='lbum-person-social-container'>";
        if ( $person_social_icon_1 != "" ) {
            $output .= do_shortcode( '[cg_social_icons icon="' . $person_social_icon_1 . '" size="fa-lg" url="' . $person_social_icon_1_url . '"]' );
        }
        if ( $person_social_icon_2 != "" ) {
            $output .= do_shortcode( '[cg_social_icons icon="' . $person_social_icon_2 . '" size="fa-lg" url="' . $person_social_icon_2_url . '"]' );
        }
        if ( $person_social_icon_3 != "" ) {
            $output .= do_shortcode( '[cg_social_icons icon="' . $person_social_icon_3 . '" size="fa-lg" url="' . $person_social_icon_3_url . '"]' );
        }
        if ( $person_social_icon_4 != "" ) {
            $output .= do_shortcode( '[cg_social_icons icon="' . $person_social_icon_4 . '" size="fa-lg" url="' . $person_social_icon_4_url . '"]' );
        }
        if ( $person_social_icon_5 != "" ) {
            $output .= do_shortcode( '[cg_social_icons icon="' . $person_social_icon_5 . '" size="fa-lg" url="' . $person_social_icon_5_url . '"]' );
        }

        $output .= "</div>";
        $output .= "</div>";
        $output .= "</div>";
        $output .= "</div>";
        return $output;
    }

}
add_shortcode( 'lbum_person', 'lbum_person' );


// [lbum_card_pay]
if ( !function_exists( 'lbum_card_pay' ) ) :

    function lbum_card_pay( $atts, $content = null ) {
        extract( shortcode_atts( array(
            'type' => 'visa',
                        ), $atts ) );

        $output = "";
        $output .= "<span class='lbum-card'>";

        if ( $type != "" ) {
            if ( $type == 'visa' ) {
                $output .= '<img src="' . LBUM_PLUGIN_URL . 'images/visa.png" alt="Visa">';
            } elseif ( $type == 'mastercard' ) {
                $output .= '<img src="' . LBUM_PLUGIN_URL . 'images/mc.png" alt="Mastercard">';
            } elseif ( $type == 'amex' ) {
                $output .= '<img src="' . LBUM_PLUGIN_URL . 'images/amex.png" alt="American Express">';
            } elseif ( $type == 'paypal' ) {
                $output .= '<img src="' . LBUM_PLUGIN_URL . 'images/paypal.png" alt="Paypal">';
            } elseif ( $type == 'discover' ) {
                $output .= '<img src="' . LBUM_PLUGIN_URL . 'images/discover.png" alt="Discover">';
            } elseif ( $type == 'maestro' ) {
                $output .= '<img src="' . LBUM_PLUGIN_URL . 'images/maestro.png" alt="Maestro">';
            }
        }

        $output .= "</span>";
        return $output;
    }

    add_shortcode( 'lbum_card_pay', 'lbum_card_pay' );
endif;


// [section]
function lbum_section_shortcode( $params = array(), $content = null ) {

    $formatting = array(
        '&nbsp;' => '',
        '<p></p>' => '',
        '<p>[' => '[',
        ']</p>' => ']',
        ']<br />' => ']',
        '<br>[' => '[',
    );
    $content = strtr( $content, $formatting );
    $content = do_shortcode( $content );
    $container = '<section>' . $content . '</section>';
    return $container;
}

add_shortcode( 'lbum_section', 'lbum_section_shortcode' );


