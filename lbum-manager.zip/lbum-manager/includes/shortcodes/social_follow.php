<?php
// [social_follow]
function social_follow($atts, $content = null) {
	$sliderrandomid = rand();
	extract(shortcode_atts(array(
		'style' => 'circle',
		'twitter' => '',
		'facebook' => '',
		'pinterest' => '',
		'email' => '',
		'googleplus' => '',
		'instagram' => '',
		'rss' => '',
		'linkedin' => '',
		'youtube' => '',
		'flickr' => '',
	), $atts));
	ob_start();
	?>

    <div class="social-icons <?php echo esc_attr($style); ?>">

    	<?php if($facebook){ ?>
    	<a href="<?php echo esc_url($facebook); ?>" target="_blank"  class="icon icon_facebook" data-toggle="tooltip" data-placement="top" title="<?php esc_html_e('Follow us on Facebook','axiosy') ?>"><i class="fa fa-facebook"></i></a>
		<?php }?>
		<?php if($twitter){ ?>
		       <a href="<?php echo esc_url($twitter); ?>" target="_blank" class="icon icon_twitter" data-toggle="tooltip" data-placement="top" title="<?php esc_html_e('Follow us on Twitter','axiosy') ?>"><i class="fa fa-twitter"></i></a>
		<?php }?>
		<?php if($email){ ?>
		       <a href="mailto:<?php echo esc_url($email); ?>" target="_blank" class="icon icon_email" data-toggle="tooltip" data-placement="top" title="<?php esc_html_e('Send us an email','axiosy') ?>"><i class="fa fa-envelope"></i></a>
		<?php }?>
		<?php if($pinterest){ ?>
		       <a href="<?php echo esc_url($pinterest); ?>" target="_blank" class="icon icon_pintrest" data-toggle="tooltip" data-placement="top" title="<?php esc_html_e('Pinterest','axiosy') ?>"><i class="fa fa-pinterest"></i></a>
		<?php }?>
		<?php if($googleplus){ ?>
		       <a href="<?php echo esc_url($googleplus); ?>" target="_blank" class="icon icon_googleplus" data-toggle="tooltip" data-placement="top" title="<?php esc_html_e('Google+','axiosy')?>"><i class="fa fa-google-plus"></i></a>
		<?php }?>
		<?php if($instagram){ ?>
		       <a href="<?php echo esc_url($instagram); ?>" target="_blank" class="icon icon_instagram" data-toggle="tooltip" data-placement="top" title="<?php esc_html_e('Instagram','axiosy')?>"><i class="fa fa-instagram"></i></a>
		<?php }?>
		<?php if($rss){ ?>
		       <a href="<?php echo esc_url($rss); ?>" target="_blank" class="icon icon_rss" data-toggle="tooltip" data-placement="top" title="<?php esc_html_e('Subscribe to RSS','axiosy') ?>"><i class="fa fa-rss"></i></a>
		<?php }?>
		<?php if($linkedin){ ?>
		       <a href="<?php echo esc_url($linkedin); ?>" target="_blank" class="icon icon_linkedin" data-toggle="tooltip" data-placement="top" title="<?php esc_html_e('LinkedIn','axiosy') ?>"><i class="fa fa-linkedin"></i></a>
		<?php }?>
		<?php if($youtube){ ?>
		       <a href="<?php echo esc_url($youtube); ?>" target="_blank" class="icon icon_youtube" data-toggle="tooltip" data-placement="top" title="<?php esc_html_e('YouTube','axiosy') ?>"><i class="fa fa-youtube"></i></a>
		<?php }?>
		<?php if($flickr){ ?>
		       <a href="<?php echo esc_url($flickr); ?>" target="_blank" class="icon icon_flickr" data-toggle="tooltip" data-placement="top" title="<?php esc_html_e('Flickr','axiosy') ?>"><i class="fa fa-flickr"></i></a>
		<?php }?>
     </div>
    	

	<?php
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}
add_shortcode("social_follow", "social_follow");

?>
