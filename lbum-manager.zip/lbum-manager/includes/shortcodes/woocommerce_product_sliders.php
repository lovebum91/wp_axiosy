<?php

function lbum_owlslider_js($owlsliderjsid, $count_items){
	?>
	<script>

	jQuery(document).ready(function($) {
		$("#owlslider_<?php echo $owlsliderjsid ?>").owlCarousel({
			items : <?php echo $count_items?>,
			lazyLoad : true,
			navigation : true,
			itemsDesktop : [1000,3], //5 items between 1000px and 901pxs
          	itemsDesktopSmall : [950,2], // 2 items betweem 900px and 601px
          	itemsTablet: [670,2], //2 items between 600 and 0;
          	itemsMobile : [450,1],
			navigationText: [
		  	"<i class='ion-ios-arrow-thin-left'></i>",
		  	"<i class='ion-ios-arrow-thin-right'></i>",
		  	]
		}); 

	});
	</script>
<?php }
	function lbum_owlslider_tworow_js($owlsliderjsid, $count_items){
		?>
		<script>

		jQuery(document).ready(function($) {
			$("#owlslider_<?php echo $owlsliderjsid ?>").owlCarousel({
				items : <?php echo $count_items?>,
				lazyLoad : true,
				navigation : true,
				itemsDesktop : [1000,2], //5 items between 1000px and 901pxs
	          	itemsDesktopSmall : [900,2], // 2 items betweem 900px and 601px
	          	itemsTablet: [600,2], //2 items between 600 and 0;
	          	itemsMobile : [450,1],
				navigationText: [
			  	"<i class='ion-ios-arrow-thin-left'></i>",
			  	"<i class='ion-ios-arrow-thin-right'></i>",
			  	]
			}); 

		});
		</script>
<?php }

/*Loadmore*/
function lbum_loadmore_js($loadmoreid, $count_items){
	$count_items_temp = $count_items * 2;
	?>
	<script>

	jQuery(document).ready(function($) {
		jQuery("#loadmore_"+<?php echo $loadmoreid?> + " .item").slice(0, <?php echo $count_items_temp ?>).show();
        jQuery(".loadMore").on('click', function (e) {
            $(".loadMore").addClass('loading');
            e.preventDefault();
            $("#loadmore_"+<?php echo $loadmoreid?> + " .item:hidden").slice(0, <?php echo $count_items ?>).slideDown();
            if ($("#loadmore_"+<?php echo $loadmoreid?> + " .item:hidden").length == 0) {
                $(".load-more-product").hide();
            }

            //
            setTimeout(function(){ 
            	$(".loadMore").removeClass('loading');
            }, 2000);

            $('html,body').animate({
            	scrollTop: $(this).offset().top
            }, 1000);
        });
	});
	</script>
<?php }

// By On Sale Products 

function lbum_woo_on_sale_products($atts, $content = null) {
	global $woocommerce;
	$owlid = rand();
	extract(shortcode_atts(array(
		"introtext" => 'Product On Sale',
		'styles' => 'grid',
		'products'  => '12',
		'display_items_grid' => '4',
		'display_items'  => '4',
        'orderby' => 'date',
        'order' => 'desc',
        "animation" => "none",
		'animation_delay' => '',
	), $atts));

	//Animation
	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = 'data-delay="'.$animation_delay.'"';

	/*Column by bootstrap*/
	$display_items_grid_temp = '4';
	if($display_items_grid == '2')
		$display_items_grid_temp = '6';
	else if($display_items_grid == '3')
		$display_items_grid_temp = '4';
	else if ($display_items_grid == '4')
		$display_items_grid_temp = '3';
	else 
		$display_items_grid_temp = '2';

	$display_items_grid_temp = esc_attr($display_items_grid_temp);
	ob_start();
	?>
    
    <?php 
	/**
	* Check if WooCommerce is active
	**/
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	?>
    
    <!--Gird-->
    <?php if($styles == 'grid'): ?>
    <div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode product-grid <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div class="pd-onsale">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
	                'meta_query' => array(
							array(
								'key' => '_visibility',
								'value' => array('catalog', 'visible'),
								'compare' => 'IN'
							),
							array(
								'key' => '_sale_price',
								'value' =>  0,
								'compare'   => '>',
								'type'      => 'NUMERIC'
							)
						),
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>
				    	<div class="item col-lg-<?php echo $display_items_grid_temp ?> col-md-<?php echo $display_items_grid_temp ?> col-sm-6 col-xs-12">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>
   
    <!--Slider-->
    <?php elseif($styles == 'slider'): ?>
 	<?php lbum_owlslider_js($owlid,$display_items)?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode slider <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
	                'meta_query' => array(
							array(
								'key' => '_visibility',
								'value' => array('catalog', 'visible'),
								'compare' => 'IN'
							),
							array(
								'key' => '_sale_price',
								'value' =>  0,
								'compare'   => '>',
								'type'      => 'NUMERIC'
							)
						),
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>

	<!--loadmore-->
    <?php elseif($styles == 'loadmore'): ?>
    <?php lbum_loadmore_js($owlid, $display_items_grid) ?>
    <div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode product-loadmore <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div class="pd-onsale" id="loadmore_<?php echo $owlid ?>">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
	                'meta_query' => array(
							array(
								'key' => '_visibility',
								'value' => array('catalog', 'visible'),
								'compare' => 'IN'
							),
							array(
								'key' => '_sale_price',
								'value' =>  0,
								'compare'   => '>',
								'type'      => 'NUMERIC'
							)
						),
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>
				    	<div class="item col-lg-<?php echo $display_items_grid_temp ?> col-md-<?php echo $display_items_grid_temp ?> col-sm-6 col-xs-12">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
		<div class="load-more-product"><a href="#" class="loadMore">z<i class="fa fa-spinner fa-pulse fa-1x fa-fw margin-bottom"></i>Load more</a></div>
	</div>

	<?php elseif($styles == 'list'): ?>
    <div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode product-list <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div class="pd-onsale">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
	                'meta_query' => array(
							array(
								'key' => '_visibility',
								'value' => array('catalog', 'visible'),
								'compare' => 'IN'
							),
							array(
								'key' => '_sale_price',
								'value' =>  0,
								'compare'   => '>',
								'type'      => 'NUMERIC'
							)
						),
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>
				    	<div class="item col-md-12">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>

	<?php elseif($styles == 'slider2row'): ?>
	<?php lbum_owlslider_tworow_js($owlid,$display_items)?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode slider2row slider <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
	                'meta_query' => array(
							array(
								'key' => '_visibility',
								'value' => array('catalog', 'visible'),
								'compare' => 'IN'
							),
							array(
								'key' => '_sale_price',
								'value' =>  0,
								'compare'   => '>',
								'type'      => 'NUMERIC'
							)
						),
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );
				$i = 2;
				$k = 0;
				$count = $products->post_count;
				if ( $products->have_posts() ) : ?>
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>
				    	<?php if($i % 2 == 0) : ?>
				    	<div class="item">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	
				    	<?php 
				    		$i--;
				    		$k++;
				    		else :
				    	?>
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div><!--/item-->
				    	<?php $i++; $k++; ?>				    		
				    	<?php endif ?>
				    	
						<?php if($count %2 != 0 && $count == $k){ ?>
				    		</div><!--/item-->
				    	<?php }?>
				    <?php endwhile; // end of the loop. ?>	    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>

	<?php else: ?>
	<?php lbum_owlslider_tworow_js($owlid,$display_items)?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode slider1row-nopadding slider <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
	                'meta_query' => array(
							array(
								'key' => '_visibility',
								'value' => array('catalog', 'visible'),
								'compare' => 'IN'
							),
							array(
								'key' => '_sale_price',
								'value' =>  0,
								'compare'   => '>',
								'type'      => 'NUMERIC'
							)
						),
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product-intimex' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>
	<?php endif ?>

    <?php } ?>

	<?php
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

// By Category Products 

function lbum_woo_categories_products($atts, $content = null) {
	global $woocommerce;
	$owlid = rand();
	extract(shortcode_atts(array(
		"introtext" => 'Product by category',
		'category'	=> '',
		'styles' => 'grid',
		'products'  => '12',
		'display_items_grid' => '4',
		'display_items'  => '4',
        'orderby' => 'date',
        'order' => 'desc',
        "animation" => "none",
		'animation_delay' => '',
	), $atts));
	
	//Animation
	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = '';

	/*Column by bootstrap*/
	$display_items_grid_temp = '4';
	if($display_items_grid == '2')
		$display_items_grid_temp = '6';
	else if($display_items_grid == '3')
		$display_items_grid_temp = '4';
	else if ($display_items_grid == '4')
		$display_items_grid_temp = '3';
	else 
		$display_items_grid_temp = '2';

	$display_items_grid_temp = esc_attr($display_items_grid_temp);

	ob_start();

	?>
    
    <?php 
	/**
	* Check if WooCommerce is active
	**/
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	?>
    
    <?php if($styles == 'grid'): ?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode product-grid <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div class="pd-categories">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
	                'meta_query' 	=> array(
							array(
								'key' 			=> '_visibility',
								'value' 		=> array('catalog', 'visible'),
								'compare' 		=> 'IN'
							)
						),
						'tax_query' 			=> array(
							array(
								'taxonomy' 		=> 'product_cat',
								'terms' 		=> array( esc_attr($category) ),
								'field' 		=> 'slug',
								'operator' 		=> 'IN'
							)
						),	
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item col-lg-<?php echo $display_items_grid_temp ?> col-md-<?php echo $display_items_grid_temp ?> col-sm-6 col-xs-12">
					    	<ul>
					    		<?php wc_get_template_part( 'content', 'product' ); ?>
					    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>

	<?php elseif($styles == 'slider'): ?>
	<?php lbum_owlslider_js($owlid,$display_items)?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode slider <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
	                'meta_query' 	=> array(
							array(
								'key' 			=> '_visibility',
								'value' 		=> array('catalog', 'visible'),
								'compare' 		=> 'IN'
							)
						),
						'tax_query' 			=> array(
							array(
								'taxonomy' 		=> 'product_cat',
								'terms' 		=> array( esc_attr($category) ),
								'field' 		=> 'slug',
								'operator' 		=> 'IN'
							)
						),	
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>
	
	<?php elseif($styles == 'loadmore'): ?>
    <?php lbum_loadmore_js($owlid, $display_items_grid) ?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode product-loadmore <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div class="pd-categories" id="loadmore_<?php echo $owlid ?>">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
	                'meta_query' 	=> array(
							array(
								'key' 			=> '_visibility',
								'value' 		=> array('catalog', 'visible'),
								'compare' 		=> 'IN'
							)
						),
						'tax_query' 			=> array(
							array(
								'taxonomy' 		=> 'product_cat',
								'terms' 		=> array( esc_attr($category) ),
								'field' 		=> 'slug',
								'operator' 		=> 'IN'
							)
						),	
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item col-lg-<?php echo $display_items_grid_temp ?> col-md-<?php echo $display_items_grid_temp ?> col-sm-6 col-xs-12">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
		<div class="load-more-product"><a href="#" class="loadMore"><i class="fa fa-spinner fa-pulse fa-1x fa-fw margin-bottom"></i>Load more</a></div>
	</div>

	<?php elseif($styles == 'list'): ?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode product-list <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div class="pd-categories">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
	                'meta_query' 	=> array(
							array(
								'key' 			=> '_visibility',
								'value' 		=> array('catalog', 'visible'),
								'compare' 		=> 'IN'
							)
						),
						'tax_query' 			=> array(
							array(
								'taxonomy' 		=> 'product_cat',
								'terms' 		=> array( esc_attr($category) ),
								'field' 		=> 'slug',
								'operator' 		=> 'IN'
							)
						),	
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item col-md-12">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>

	<?php elseif($styles == 'slider2row'): ?>
	<?php lbum_owlslider_tworow_js($owlid,$display_items)?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode slider2row slider <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
	                'meta_query' 	=> array(
							array(
								'key' 			=> '_visibility',
								'value' 		=> array('catalog', 'visible'),
								'compare' 		=> 'IN'
							)
						),
						'tax_query' 			=> array(
							array(
								'taxonomy' 		=> 'product_cat',
								'terms' 		=> array( esc_attr($category) ),
								'field' 		=> 'slug',
								'operator' 		=> 'IN'
							)
						),	
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product-intimex' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>

	<?php else: ?>
	<?php lbum_owlslider_tworow_js($owlid,$display_items)?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode slider1row-nopadding slider <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
	                'meta_query' 	=> array(
							array(
								'key' 			=> '_visibility',
								'value' 		=> array('catalog', 'visible'),
								'compare' 		=> 'IN'
							)
						),
						'tax_query' 			=> array(
							array(
								'taxonomy' 		=> 'product_cat',
								'terms' 		=> array( esc_attr($category) ),
								'field' 		=> 'slug',
								'operator' 		=> 'IN'
							)
						),	
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item">
					    	<ul>
					    		<?php wc_get_template_part( 'content', 'product-intimex' ); ?>
					    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>
	<?php endif ?>

    <?php } ?>

	<?php
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

// Latest Products. 

function lbum_woo_latest_products($atts, $content = null) {
	global $woocommerce;
	$owlid = rand();
	extract(shortcode_atts(array(
		"introtext" => 'Bestsellers',
		'styles' => 'grid',
		'products'  => '12',
		'display_items_grid' => '4',
		'display_items'  => '4',
        'orderby' => 'date',
        'order' => 'desc',
        "animation" => "none",
		'animation_delay' => '',
	), $atts));
	
	//Animation
	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = '';

	/*Column by bootstrap*/
	$display_items_grid_temp = '4';
	if($display_items_grid == '2')
		$display_items_grid_temp = '6';
	else if($display_items_grid == '3')
		$display_items_grid_temp = '4';
	else if ($display_items_grid == '4')
		$display_items_grid_temp = '3';
	else 
		$display_items_grid_temp = '2';

	$display_items_grid_temp = esc_attr($display_items_grid_temp);

	ob_start();

	?>
    
    <?php 
	/**
	* Check if WooCommerce is active
	**/
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	?>
   
   	<?php if($styles == 'grid'): ?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode product-grid <?php echo $animation_style ?>">
		<div class="row">
				<div class="col-lg-12">
					<?php if(!empty($introtext)) { ?>
					<div class="titlewrap">
						<h2><?php echo $introtext; ?></h2>
					</div>
					<?php } ?>
				</div>
				<div class="pd-latest">

					<?php
					$args = array(
					    'post_type' => 'product',
						'post_status' => 'publish',
						'ignore_sticky_posts'   => 1,
						'posts_per_page' => $products
					);
					// Hide hidden items
					$args['meta_query'][] = WC()->query->visibility_meta_query();

					$products = new WP_Query( $args );

					if ( $products->have_posts() ) : ?>
					            
					    <?php while ( $products->have_posts() ) : $products->the_post(); ?>
						
						<div class="item col-lg-<?php echo $display_items_grid_temp ?> col-md-<?php echo $display_items_grid_temp ?> col-sm-6 col-xs-12">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

					    <?php endwhile; // end of the loop. ?>
					    
					<?php
					endif; 
					wp_reset_postdata();
					?>
				</div>
		</div>
	</div>

   	<?php elseif($styles == 'slider'): ?>
 	<?php lbum_owlslider_js($owlid, $display_items); ?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode slider <?php echo $animation_style ?>">
		<div class="row">
				<div class="col-lg-12">
					<?php if(!empty($introtext)) { ?>
					<div class="titlewrap">
						<h2><?php echo $introtext; ?></h2>
					</div>
					<?php } ?>
				</div>
				<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">

					<?php
					$args = array(
					    'post_type' => 'product',
						'post_status' => 'publish',
						'ignore_sticky_posts'   => 1,
						'posts_per_page' => $products
					);
					// Hide hidden items
					$args['meta_query'][] = WC()->query->visibility_meta_query();

					$products = new WP_Query( $args );

					if ( $products->have_posts() ) : ?>
					            
					    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

					    	<div class="item">
					    	<ul>
					    		<?php 
					    			wc_get_template_part( 'content', 'product' ); 
					    		?>
					    	</ul>
					    	</div>

					    <?php endwhile; // end of the loop. ?>
					    
					<?php
					endif; 
					wp_reset_postdata();
					?>
				</div>
		</div>
	</div>
	
	<?php elseif($styles == 'loadmore'): ?>
    <?php lbum_loadmore_js($owlid, $display_items_grid) ?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode product-loadmore <?php echo $animation_style ?>">
		<div class="row">
				<div class="col-lg-12">
					<?php if(!empty($introtext)) { ?>
					<div class="titlewrap">
						<h2><?php echo $introtext; ?></h2>
					</div>
					<?php } ?>
				</div>
				<div class="pd-latest" id="loadmore_<?php echo $owlid ?>">

					<?php
					$args = array(
					    'post_type' => 'product',
						'post_status' => 'publish',
						'ignore_sticky_posts'   => 1,
						'posts_per_page' => $products
					);
					// Hide hidden items
					$args['meta_query'][] = WC()->query->visibility_meta_query();

					$products = new WP_Query( $args );

					if ( $products->have_posts() ) : ?>
					            
					    <?php while ( $products->have_posts() ) : $products->the_post(); ?>
						
						<div class="item col-lg-<?php echo $display_items_grid_temp ?> col-md-<?php echo $display_items_grid_temp ?> col-sm-6 col-xs-12">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

					    <?php endwhile; // end of the loop. ?>
					    
					<?php
					endif; 
					wp_reset_postdata();
					?>
				</div>
		</div>
		<div class="load-more-product"><a href="#" class="loadMore"><i class="fa fa-spinner fa-pulse fa-1x fa-fw margin-bottom"></i>Load more</a></div>
	</div>

	<?php elseif($styles == 'list'): ?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode product-list <?php echo $animation_style ?>">
		<div class="row">
				<div class="col-lg-12">
					<?php if(!empty($introtext)) { ?>
					<div class="titlewrap">
						<h2><?php echo $introtext; ?></h2>
					</div>
					<?php } ?>
				</div>
				<div class="pd-latest">

					<?php
					$args = array(
					    'post_type' => 'product',
						'post_status' => 'publish',
						'ignore_sticky_posts'   => 1,
						'posts_per_page' => $products
					);
					// Hide hidden items
					$args['meta_query'][] = WC()->query->visibility_meta_query();

					$products = new WP_Query( $args );

					if ( $products->have_posts() ) : ?>
					            
					    <?php while ( $products->have_posts() ) : $products->the_post(); ?>
						
						<div class="item col-md-12">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

					    <?php endwhile; // end of the loop. ?>
					    
					<?php
					endif; 
					wp_reset_postdata();
					?>
				</div>
		</div>
	</div>

	<?php elseif($styles == 'slider2row'): ?>
	<?php lbum_owlslider_tworow_js($owlid, $display_items); ?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode slider2row slider <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">

				<?php
				$args = array(
				    'post_type' => 'product',
					'post_status' => 'publish',
					'ignore_sticky_posts'   => 1,
					'posts_per_page' => $products
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );
				$i = 2;
				$k = 0;
				$count = $products->post_count;
				if ( $products->have_posts() ) : ?>
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>
				    	<?php if($i % 2 == 0) : ?>
				    	<div class="item">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	
				    	<?php 
				    		$i--;
				    		$k++;
				    		else :
				    	?>
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div><!--/item-->
				    	<?php $i++; $k++; ?>				    		
				    	<?php endif ?>
				    	
						<?php if($count %2 != 0 && $count == $k){ ?>
				    		</div><!--/item-->
				    	<?php }?>
				    <?php endwhile; // end of the loop. ?>	    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>

	<?php else: ?>
	<?php lbum_owlslider_tworow_js($owlid, $display_items); ?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode slider1row-nopadding slider <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
				<div class="titlewrap">
					<h2><?php echo $introtext; ?></h2>
				</div>
				<?php } ?>
			</div>
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">

				<?php
				$args = array(
				    'post_type' => 'product',
					'post_status' => 'publish',
					'ignore_sticky_posts'   => 1,
					'posts_per_page' => $products
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item">
				    	<ul>
				    		<?php 
				    			wc_get_template_part( 'content', 'product-intimex' ); 
				    		?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>
	<?php endif ?>

    <?php } ?>

	<?php
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

// Featured Products 

function lbum_woo_featured_products($atts, $content = null) {
	global $woocommerce;
	$owlid = rand();
	extract(shortcode_atts(array(
		"introtext" => 'Recommended for you',
		'styles' => 'grid',
		'products'  => '12',
		'display_items_grid' => '4',
		'display_items'  => '4',
        'orderby' => 'date',
        'order' => 'desc',
        "animation" => "none",
		'animation_delay' => '',
	), $atts));
	
	//Animation
	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = '';

	/*Column by bootstrap*/
	$display_items_grid_temp = '4';
	if($display_items_grid == '2')
		$display_items_grid_temp = '6';
	else if($display_items_grid == '3')
		$display_items_grid_temp = '4';
	else if ($display_items_grid == '4')
		$display_items_grid_temp = '3';
	else 
		$display_items_grid_temp = '2';

	$display_items_grid_temp = esc_attr($display_items_grid_temp);
	
	ob_start();

	?>
    
    <?php 
	/**
	* Check if WooCommerce is active
	**/
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	?>
    <?php if($styles == 'grid'): ?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode product-grid <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
					<div class="titlewrap">
						<h2><?php echo $introtext; ?></h2>
					</div>
				<?php } ?>
			</div>
			<div class="pd-featured">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_key' => '_featured',
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item col-lg-<?php echo $display_items_grid_temp ?> col-md-<?php echo $display_items_grid_temp ?> col-sm-6 col-xs-12">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>

    <?php elseif($styles == 'slider'): ?>
 	<?php lbum_owlslider_js($owlid,$display_items)?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode slider <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
					<div class="titlewrap">
						<h2><?php echo $introtext; ?></h2>
					</div>
				<?php } ?>
			</div>
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_key' => '_featured',
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>

	<?php elseif($styles == 'loadmore'): ?>
    <?php lbum_loadmore_js($owlid, $display_items_grid) ?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode product-loadmore <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
					<div class="titlewrap">
						<h2><?php echo $introtext; ?></h2>
					</div>
				<?php } ?>
			</div>
			<div class="pd-featured" id="loadmore_<?php echo $owlid ?>">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_key' => '_featured',
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item col-lg-<?php echo $display_items_grid_temp ?> col-md-<?php echo $display_items_grid_temp ?> col-sm-6 col-xs-12">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
		<div class="load-more-product"><a href="#" class="loadMore"><i class="fa fa-spinner fa-pulse fa-1x fa-fw margin-bottom"></i>Load more</a></div>
	</div>

	<?php elseif($styles == 'list'): ?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode product-list <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
					<div class="titlewrap">
						<h2><?php echo $introtext; ?></h2>
					</div>
				<?php } ?>
			</div>
			<div class="pd-featured">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_key' => '_featured',
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item col-md-12">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>

	<?php elseif($styles == 'slider2row'): ?>
	<?php lbum_owlslider_tworow_js($owlid,$display_items)?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode slider2row slider <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
					<div class="titlewrap">
						<h2><?php echo $introtext; ?></h2>
					</div>
				<?php } ?>
			</div>
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_key' => '_featured',
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );
				$i = 2;
				$k = 0;
				$count = $products->post_count;
				if ( $products->have_posts() ) : ?>
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>
				    	<?php if($i % 2 == 0) : ?>
				    	<div class="item">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	
				    	<?php 
				    		$i--;
				    		$k++;
				    		else :
				    	?>
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product' ); ?>
				    	</ul>
				    	</div><!--/item-->
				    	<?php $i++; $k++; ?>				    		
				    	<?php endif ?>
				    	
						<?php if($count %2 != 0 && $count == $k){ ?>
				    		</div><!--/item-->
				    	<?php }?>
				    <?php endwhile; // end of the loop. ?>	    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>
	
	<?php else: ?>
	<?php lbum_owlslider_tworow_js($owlid,$display_items)?>
	<div <?php echo $data_animation_style; echo $animation_delay; ?> class="product-shortcode slider1row-nopadding slider <?php echo $animation_style ?>">
		<div class="row">
			<div class="col-lg-12">
				<?php if(!empty($introtext)) { ?>
					<div class="titlewrap">
						<h2><?php echo $introtext; ?></h2>
					</div>
				<?php } ?>
			</div>
			<div id="owlslider_<?php echo $owlid ?>" class="owl-carousel">
				<?php
				$args = array(
	                'post_status' => 'publish',
	                'post_type' => 'product',
					'ignore_sticky_posts'   => 1,
	                'meta_key' => '_featured',
	                'meta_value' => 'yes',
	                'posts_per_page' => $products,
					'orderby' => $orderby,
					'order' => $order,
				);
				// Hide hidden items
				$args['meta_query'][] = WC()->query->visibility_meta_query();

				$products = new WP_Query( $args );

				if ( $products->have_posts() ) : ?>
				            
				    <?php while ( $products->have_posts() ) : $products->the_post(); ?>

				    	<div class="item">
				    	<ul>
				    		<?php wc_get_template_part( 'content', 'product-intimex' ); ?>
				    	</ul>
				    	</div>

				    <?php endwhile; // end of the loop. ?>
				    
				<?php
				endif; 
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>
	<?php endif ?>

    <?php } ?>

	<?php
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

//Add shortcode

add_shortcode("lbum_woo_on_sale_products", "lbum_woo_on_sale_products");
add_shortcode("lbum_woo_categories_products", "lbum_woo_categories_products");
add_shortcode("lbum_woo_latest_products", "lbum_woo_latest_products");
add_shortcode("lbum_woo_featured_products", "lbum_woo_featured_products");


