<?php 

// [lbum_hp_promo]

function lbum_hp_promo($params = array(), $content = null) {
  extract(shortcode_atts(array(
    'bg' => '#f6653c',
    'height' => '',
    'title' => 'This is a promo',
    'button_text' => '',
    'button_url' => ''
  ), $params));
  
  $bgcolor = "";
  if (strpos($bg,'#') !== false) {
    $bgcolor = 'background-color:'.$bg.'!important; ';
  }

  $height_style = "";
  if ($height) {
    $height_style = 'height:'.$height;
  }

  $content = do_shortcode($content);

  $button_content = "";
  if (isset($button_url, $button_text)) {
    $button_content = ' <a href="'.esc_url($button_url).'" class="btn-links">'.$button_text.'</a>';
  } else {
    $button_content = '';
  }

  $hppromo = '   
    <div class="lbum-msg-wrap highlight-block fade-in animate" style="'.esc_attr($bgcolor) . esc_attr($height_style) .'">
      <div class="lbum-msg-bg"></div>
        <div class="row">
          <div class="lbum-msg-text col-lg-12 col-md-12 animate" data-animate="slideInRight">
            <h2 class="lbum-msg-heading">'.$title . $button_content . '</h2>
          </div>
        </div>
    </div>
  ';      
  return $hppromo;
}

add_shortcode("lbum_promo", "lbum_hp_promo");
