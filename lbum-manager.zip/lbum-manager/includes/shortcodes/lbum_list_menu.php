<?php 

// [lbum_list_menu]

function lbum_list_menu($params = array(), $content = null) {
  extract(shortcode_atts(array(
    'key_word' => 'Women',
    'key_color' => '#202020',
	'extra_class' => '',
	'animation' => 'none',
	'animation_delay' => '',
  ), $params));
	
	if(!empty($extra_class)){
		$extra_class = esc_attr($extra_class);
	}
	
	//Animation
	$animation_style = "";
	$data_animation_style = "";
	if ($animation !== "none") {
		$animation_style = 'animate';
		$data_animation_style = 'data-animate="' . $animation .'"';
	}
	$animation_delay = 'data-delay="'.$animation_delay.'"';
	$animation_style = esc_attr($animation_style);
	
	$content = wpautop(do_shortcode($content));
	$html = '';
	$html .= '<div class="ul-list-menu '.$extra_class.' '.$animation_style.'" '.$data_animation_style.' '.$animation_delay.'>';
	$html .= '<div class="ul-key-word" style="color: '.$key_color.'">'. $key_word .'</div>';
	$html .= '<div class="ul-content"><p>'. $content .'</div>';
	$html .= '</div>';
	
	return $html;
}
add_shortcode("lbum_list_menu", "lbum_list_menu");
