<?php

$labels = array(
    'name' => esc_html__( 'Portfolio', 'axiosy' ),
    'singular_name' => esc_html__( 'Portfolio', 'axiosy' ),
    'rewrite' => array( 'slug' => esc_html__( 'portfolio', 'axiosy' ) ),
    'add_new' => _x( 'Add New', 'portfolio', 'axiosy' ),
    'add_new_item' => esc_html__( 'Add New Portfolio', 'axiosy' ),
    'edit_item' => esc_html__( 'Edit Portfolio', 'axiosy' ),
    'new_item' => esc_html__( 'New Portfolio', 'axiosy' ),
    'view_item' => esc_html__( 'View Portfolio', 'axiosy' ),
    'search_items' => esc_html__( 'Search Portfolios', 'axiosy' ),
    'not_found' => esc_html__( 'No portfolios found', 'axiosy' ),
    'not_found_in_trash' => esc_html__( 'No portfolios found in Trash', 'axiosy' ),
    'parent_item_colon' => ''
);

$args = array(
    'labels' => $labels,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'portfolio' ),
    'capability_type' => 'post',
    'hierarchical' => false,
    'menu_position' => null,
    'menu_icon' => 'dashicons-portfolio',
    'supports' => array( 'title', 'excerpt', 'editor', 'thumbnail' )
);

register_post_type( 'portfolios', $args );

function lbum_portfolios_edit_columns( $columns ) {
    $columns = array(
        "cb" => "<input type=\"checkbox\" />",
        "title" => esc_html__( 'Title', 'axiosy' ),
        "date" => esc_html__( 'Date', 'axiosy' )
    );
    return $columns;
}

add_filter( 'manage_edit-portfolios_columns', 'lbum_portfolios_edit_columns' );
