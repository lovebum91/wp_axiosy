<?php

$labels = array(
    'name' => esc_html__( 'Testimonials', 'axiosy' ),
    'singular_name' => esc_html__( 'Testimonial', 'axiosy' ),
    'add_new' => esc_html__( 'Add New', 'axiosy' ),
    'add_new_item' => esc_html__( 'Add New Testimonial', 'axiosy' ),
    'edit_item' => esc_html__( 'Edit Testimonial', 'axiosy' ),
    'new_item' => esc_html__( 'New Testimonial', 'axiosy' ),
    'view_item' => esc_html__( 'View Testimonial', 'axiosy' ),
    'search_items' => esc_html__( 'Search Testimonials', 'axiosy' ),
    'not_found' => esc_html__( 'No Testimonials found', 'axiosy' ),
    'not_found_in_trash' => esc_html__( 'No Testimonials in trash', 'axiosy' ),
    'parent_item_colon' => ''
);

$args = array(
    'labels' => $labels,
    'public' => false,
    'exclude_from_search' => true,
    'publicly_queryable' => false,
    'rewrite' => array( 'slug' => 'testimonials' ),
    'show_ui' => true,
    'query_var' => true,
    'capability_type' => 'post',
    'hierarchical' => false,
    'menu_position' => 35,
    'menu_icon' => 'dashicons-format-quote',
    'has_archive' => false,
    'supports' => array( 'title', 'editor' )
);

register_post_type( 'testimonials', $args );

function lbum_testimonials_edit_columns( $columns ) {
    $columns = array(
        "cb" => "<input type=\"checkbox\" />",
        "title" => esc_html__( 'Testimonial Title', 'axiosy' ),
        "date" => esc_html__( 'Date', 'axiosy' )
    );
    return $columns;
}

add_filter( 'manage_edit-testimonials_columns', 'lbum_testimonials_edit_columns' );
