<?php

$labels = array(
    'name' => esc_html__( 'Announcements Cookie', 'axiosy' ),
    'singular_name' => esc_html__( 'Announcement Cookie', 'axiosy' ),
    'add_new' => esc_html__( 'Add New', 'axiosy' ),
    'add_new_item' => esc_html__( 'Add New Announcement', 'axiosy' ),
    'edit_item' => esc_html__( 'Edit Announcement', 'axiosy' ),
    'new_item' => esc_html__( 'New Announcement', 'axiosy' ),
    'view_item' => esc_html__( 'View Announcement', 'axiosy' ),
    'search_items' => esc_html__( 'Search Announcements', 'axiosy' ),
    'not_found' => esc_html__( 'No Announcements found', 'axiosy' ),
    'not_found_in_trash' => esc_html__( 'No Announcements in trash', 'axiosy' ),
    'parent_item_colon' => ''
);

$args = array(
    'labels' => $labels,
    'public' => false,
    'exclude_from_search' => true,
    'publicly_queryable' => false,
    'rewrite' => array( 'slug' => 'cookieannouncements' ),
    'show_ui' => true,
    'query_var' => true,
    'capability_type' => 'post',
    'hierarchical' => false,
    'menu_position' => 35,
    'menu_icon' => 'dashicons-megaphone',
    'has_archive' => false,
    'supports' => array( 'title', 'editor' )
);

register_post_type( 'cookieannouncements', $args );

function lbum_cookieannouncements_edit_columns( $columns ) {
    $columns = array(
        "cb" => "<input type=\"checkbox\" />",
        "title" => esc_html__( 'Title', 'axiosy' ),
        "date" => esc_html__( 'Date', 'axiosy' )
    );
    return $columns;
}

add_filter( 'manage_edit-cookieannouncements_columns', 'lbum_cookieannouncements_edit_columns' );
