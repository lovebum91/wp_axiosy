<?php

$labels = array(
    'name' => esc_html__( 'Brands', 'axiosy' ),
    'singular_name' => esc_html__( 'Brands', 'axiosy' ),
    'add_new' => esc_html__( 'Add New', 'axiosy' ),
    'add_new_item' => esc_html__( 'Add New', 'axiosy' ),
    'edit_item' => esc_html__( 'Edit', 'axiosy' ),
    'new_item' => esc_html__( 'New Items', 'axiosy' ),
    'view_item' => esc_html__( 'View Items', 'axiosy' ),
    'search_items' => esc_html__( 'Search Items', 'axiosy' ),
    'not_found' => esc_html__( 'No Brands found', 'axiosy' ),
    'not_found_in_trash' => esc_html__( 'No Brands in trash', 'axiosy' ),
    'parent_item_colon' => ''
);

$args = array(
    'labels' => $labels,
    'public' => false,
    'exclude_from_search' => true,
    'publicly_queryable' => false,
    'rewrite' => array( 'slug' => 'brands' ),
    'show_ui' => true,
    'query_var' => true,
    'capability_type' => 'post',
    'hierarchical' => false,
    'menu_position' => 35,
    'menu_icon' => 'dashicons-align-none',
    'has_archive' => false,
    'supports' => array( 'title', 'editor' )
);

register_post_type( 'brands', $args );

function lbum_brands_edit_columns( $columns ) {
    $columns = array(
        "cb" => "<input type=\"checkbox\" />",
        "title" => esc_html__( 'Items Name', 'axiosy' ),
        "date" => esc_html__( 'Date', 'axiosy' )
    );
    return $columns;
}

add_filter( 'manage_edit-logos_columns', 'lbum_brands_edit_columns' );
